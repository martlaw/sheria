-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 09, 2018 at 01:51 PM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `less_dashboard`
--

-- --------------------------------------------------------

--
-- Table structure for table `less_admins`
--

CREATE TABLE `less_admins` (
  `uid` int(255) NOT NULL,
  `uname` varchar(255) NOT NULL,
  `uemail` varchar(255) NOT NULL,
  `upass` varchar(255) NOT NULL,
  `utype` varchar(25) NOT NULL DEFAULT 'normal',
  `ulmodi` varchar(255) NOT NULL DEFAULT 'none'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `less_admins`
--

INSERT INTO `less_admins` (`uid`, `uname`, `uemail`, `upass`, `utype`, `ulmodi`) VALUES
(1, 'bless siyovelwa', 'test@test.com', '512119997acf2ee4e1e0687fdb19539d', 'normal', 'Sep 16, 2017 - 13:52'),
(2, 'nahshon', 'nahshon@gmail.com', '512119997acf2ee4e1e0687fdb19539d', 'sasa', 'Sep 09, 2017 - 01:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `less_admins`
--
ALTER TABLE `less_admins`
  ADD PRIMARY KEY (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `less_admins`
--
ALTER TABLE `less_admins`
  MODIFY `uid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
