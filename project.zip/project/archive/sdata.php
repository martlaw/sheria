<?php

    class sdata{
        
        private $uid,$udata,$ulevel,$ifunc;
        private $mysqli,$dataSql,$dataQuery,$dataRows,$dataFetch,
                $dtSql,$dtQuery,$dtRows,$dtFetch,
                $dt2Sql,$dt2Query,$dt2Rows,$dt2Fetch,
                $dt3Sql,$dt3Query,$dt3Rows,$dt3Fetch,
                $dt4Sql,$dt4Query,$dt4Rows,$dt4Fetch,
                $sdata,$sdata1,$sdata2;
        
        private $tbname,$dataRowIds;
        
        private $rowID,$tmpRowID;
        
        function __construct($mysqli){
            $this->mysqli   =   $mysqli;
            $this->uid          =   $_SESSION["unas_uid"];
        }
        
        function createSQL($adata,$s,$e){   // alldata,start,end,
            $this->sdata        =   "";
            for($i=$s;$i<=$e;$i++){
                $this->sdata    .=  "'".$adata[$i]."'";
                if($i!=$e){ $this->sdata    .=  ","; }
            }
            
            return $this->sdata;
        }

        function runSQL($sql,$db,$sqlCond){
            $this->dtSql    =   $sql;
            $this->tbname   =   $db;
            
            // clear existing data
            $this->clearExistingData($sqlCond);
            
            // save new data
            
            for($s=0;$s<count($this->dtSql);$s++){
                //echo $this->dtSql[$s]."<br>";
                if($this->dtQuery   =   $this->mysqli->query($this->dtSql[$s])){
                    $this->rowID    =   $this->mysqli->insert_id;
                }
                else{ $this->rowID  =   "failed";}
            }
            
            return $this->rowID;
        }
        
        function clearExistingData($sqlCond){
            $this->dt2Sql   =   "SELECT * FROM `$this->tbname` WHERE uid='$this->uid'".$sqlCond;
            $this->dt2Query =   $this->mysqli->query($this->dt2Sql);
            $this->dt2Rows  =   $this->dt2Query->num_rows;
            if($this->dt2Rows>0){
                while($this->dt2Fetch= $this->dt2Query->fetch_assoc()){
                    $this->tmpRowID = $this->dt2Fetch["id"];
                    $this->dt3Sql   =   "DELETE FROM `$this->tbname` WHERE id='$this->tmpRowID'";
                    $this->mysqli->query($this->dt3Sql);
                }
            }
        }
        
        
    }
?>