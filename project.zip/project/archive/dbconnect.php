<?php
    $dbhost =   "localhost";
    $dbuser =   "root";
    $dbpass =   "";
    $dbname =   "legal_bank";
    
    $mysqli =   new mysqli($dbhost,$dbuser,$dbpass,$dbname);
    
    
    $dbnameAR       =   array();
    $dbnameAR[0]    =   "martlaw_less_dashboard";
    $dbnameAR[1]    =   "martlaw_legal_bank";
    $dbnameAR[2]    =   "";
    
    
    $mysqliAR       =   array();
    $mysqliAR[0]    =   new mysqli($dbhost,$dbuser,$dbpass,$dbnameAR[0]);
    $mysqliAR[1]    =   new mysqli($dbhost,$dbuser,$dbpass,$dbnameAR[1]);
    $mysqliAR[2]    =   new mysqli($dbhost,$dbuser,$dbpass,$dbnameAR[2]);

?>