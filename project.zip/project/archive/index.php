<?php session_start(); ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title>Legal Bank | HOME</title>
        <?php include'head.php'; ?>
    </head>
    <body>
        <?php 
            include 'nav.php';
            include 'less/dba.php';
            $action =   "register";
            if(isset($_GET["action"])){
                $action = htmlentities($_GET["action"]);
            }
        ?>
        <?php if((isset($_SESSION["tls_login"]))&&($_SESSION["tls_login"]==true)):?>
            <div class="cards">
                <?php 
                    include 'dbconnect.php';
                    include 'ifunc.php';
                    $ifunc  =   new ifunc($mysqli);
                ?>
                <div id="b-leftCards">
                    <div class="searchAR">
                        <div id="cons">
                            <input type="text" id="consin" class="inline-search-in" placeholder="Enter case name | keyword"/>
                            <button id="conssub" class="inline-search-sub">search</button>
                        </div>
                    </div>
                    
                    <div class="posts">
                        <?php
                            if(isset($_GET["results"])&&isset($_GET["keyword"])&&($_GET["results"]==true)){
                                $keyword    = htmlentities($_GET["keyword"]);
                                echo '<div id="post"> <div id="rheading">searching for "'.$keyword.'"</div> </div>';
                                echo $ifunc->searchData($keyword);
                            }
                            else{
                                echo '<div class="bcseter">What can we help you with?</div>';
                                
                                # get categories
                                echo $ifunc->getCategories($mysqliAR[1],"top");
                                # end get categories
                                
                                echo '<div id="hr-black"></div>';
                                echo '<div id="post"> <div id="rheading">Most viewed</div> </div>';
                                # most viewed posts
                                echo $ifunc->getMostVisited();
                                
                            }
                        ?>
                        
                        
                    </div>
                </div>
                <?php include 'right-cards.php'; ?>
            </div>
        <?php else:?>
            <div class="home-cover">
                <div class="cards">
                    <div id="lr-card">
                        <form action="door.php?job=<?php echo $action; ?>" method="POST">
                            <div id="lr-card-con">
                                <?php if($action=="login"): ?>
                                    <title>TLS | Login</title>
                                    <h2 id="cformTitle">Login</h2>
                                    <input type="text" id="lr-fuin" name="email"   placeholder="Email or phone"/>
                                    <input type="password" id="lr-fuin" name="pass"    placeholder="password"/>
                                    <div id="cseter">
                                        <button id="lr" type="submit"> Login </button>
                                    </div>
                                <?php else: ?>
                                    <title>TLS | Register</title>
                                    <h2 id="cformTitle">Register</h2>
                                    <input type="text" id="lr-fuin" name="name"   placeholder="Full name"/>
                                    <input type="text" id="lr-fuin" name="email"   placeholder="Email"/>
                                    <input type="text" id="lr-fuin" name="phone"   placeholder="Phone"/>
                                    <input type="password" id="lr-fuin" name="pass1"    placeholder="password"/>
                                    <input type="password" id="lr-fuin" name="pass2"    placeholder="Confirm password"/>
                                    <div id="cseter">
                                        <button id="lr" type="submit"> Register </button>
                                    </div>
                                <?php endif;?>
                                <?php
                                    if(isset($_GET["error"]) && isset($_GET["msg"]) ){
                                        if($_GET["error"]=="done"){
                                            echo '<div id="cardDone">'.$_GET["msg"].'</div>';
                                        }
                                        else{
                                            echo '<div id="cardError">'.$_GET["msg"].'</div>';
                                        }
                                    }
                                ?>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        <?php endif;?>
    </body>
</html>