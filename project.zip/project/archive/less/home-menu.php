<div class="statistics">
    <?php
        $DBA    =   new dba($mysqliAR[1], "none", "none");
    ?>
    <div id="stats">
        <div id="statsIcon"><img src="icons/admin.png"/></div>
        <div id="statsTitle">Administrators</div>
        <div id="statsInfo"><?php echo $ifunc->getDBTBrows("less", "admins"); ?></div>
    </div>
    <div id="stats">
        <div id="statsIcon"><img src="icons/content.png"/></div>
        <div id="statsTitle">Judgements</div>
        <div id="statsInfo"><?php $DBA->getTBData("judgements", ""); echo count($DBA->dataTRA); ?></div>
    </div>
    <div id="stats">
        <div id="statsIcon"><img src="icons/content.png"/></div>
        <div id="statsTitle">Articles</div>
        <div id="statsInfo"><?php $DBA->getTBData("web_data", " WHERE dtype='article' "); echo count($DBA->dataTRA); ?></div>
    </div>
    <div id="stats">
        <div id="statsIcon"><img src="icons/content.png"/></div>
        <div id="statsTitle">Categories</div>
        <div id="statsInfo"><?php  $DBA->getTBData("web_data", " WHERE dtype='category' "); echo count($DBA->dataTRA);  ?></div>
    </div>
    
    <div id="stats">
        <div id="statsIcon"><img src="icons/content.png"/></div>
        <div id="statsTitle">Reports</div>
        <div id="statsInfo"><?php  $DBA->getTBData("web_data", " WHERE dtype='category' "); echo count($DBA->dataTRA);  ?></div>
    </div>
</div>