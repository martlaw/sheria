<div id="left-menu">
    <div id="less-logo"> <a href="index.php"><img src="http://edumek.com/cdn/brands/less.png"/></a> </div>
    
    <?php
        $catCtask   =   "home";
        if(isset($_GET["task"])){
            $catCtask   = htmlentities(trim($_GET["task"]));
        }

        $catName    =  array();
        $catTask    =  array();
        $catIcon    =  array();

        $catName[0] =   "Home";                     $catTask[0] =   "home";                     $catIcon[0] =   "home.png";     
        $catName[1] =   "Add to Judgements";        $catTask[1] =   "add-to-judgements";        $catIcon[1] =   "add.png";     
        $catName[2] =   "Add to Articles";          $catTask[2] =   "add-to-articles";          $catIcon[2] =   "add.png";  
        $catName[3] =   "Add to Categories";        $catTask[3] =   "add-to-categories";        $catIcon[3] =   "add.png";  
        $catName[4] =   "Notify Users";             $catTask[4] =   "notify-users";             $catIcon[4] =   "broadcast.png";
        $catName[5] =   "Reports";                  $catTask[5] =   "reports";                  $catIcon[5] =   "admin.png";
        $catName[6] =   "Add admin";                $catTask[6] =   "add-admin";                $catIcon[6] =   "admin.png";
        $catName[7] =   "Settings";                 $catTask[7] =   "settings";                 $catIcon[7] =   "settings.png";     

        for($mc=0;$mc<count($catName);$mc++){
            $catArrow   =   "left-mcat-arrow-n";
            if($catTask[$mc]==$catCtask){  $catArrow   =   "left-mcat-arrow-s"; }

            echo '  <div id="left-mcats">
                        <div id="left-mcat" data-task="'.$catTask[$mc].'">
                            <div id="left-mcat-icon"><img src="icons/'.$catIcon[$mc].'"/></div>
                            <div id="left-mcat-info">'.$catName[$mc].'</div>
                            <div id="'.$catArrow.'"></div>
                        </div>
                    </div>';


        }


    ?>
    <div id="cr"> &#xa9; <?php echo date("Y");?> less dashboards - edumek systems </div>         
</div>