<?php
    class ifunc{
        private $uid,$upass,$userData;
        private $allMysqli,$userMysqli,$mysqli,$dataSql,$dataQuery,$dataRows,$dataFetch,
                $dtSql,$dtQuery,$dtRows,$dtFetch,
                $dt1Sql,$dt1Query,$dt1Rows,$dt1Fetch,
                $dt2Sql,$dt2Query,$dt2Rows,$dt2Fetch,
                $dt3Sql,$dt3Query,$dt3Rows,$dt3Fetch,
                $dt4Sql,$dt4Query,$dt4Rows,$dt4Fetch,
                $dt5Sql,$dt5Query,$dt5Rows,$dt5Fetch,
                $dt6Sql,$dt6Query,$dt6Rows,$dt6Fetch,
                $dt7Sql,$dt7Query,$dt7Rows,$dt7Fetch,
                $dt8Sql,$dt8Query,$dt8Rows,$dt8Fetch;
        
        private $postData,$tmpData,$dataTRA,$dataTESC,$htmlTR,$html2TR,$html3TR;
        public  $dataTRAER;
        
        # function parameter
        private $fpval,$fpvalER; 
        
        # function returns
        private $funcDataTR,$funcStatus,$bulkDataTR;
        
        #time
        private $tddate,$tdtime,$tdyear;
        
        #search keyword
        private $searchKeyword;
        
        # passwords
        private $oupass,$upass1,$upass2;
        
        # image array
        private $filesArray;
        
        function __construct($mysqli) {
            $this->allMysqli    =   $mysqli;
            $this->mysqli       =   $mysqli[0];
            $this->userMysqli   =   $mysqli[1];
            
            $this->uid          =   "none";
            if(isset($_SESSION["less_uid"])){   $this->uid          =   $_SESSION["less_uid"];  }
            
            $this->dataTRAER    =   0;
            $this->dataTESC     =   "'~!*,`\":";
            $this->tddate       =   date("M d, Y - H:i");
            $this->tdtime       =   date("H:i");
            $this->tdyear       =   date("Y");
            
        }
        
        # Get $_POST Vals
        function getPostVals(){
            $this->dataTRA  =   array();
            foreach($_POST as $val){
                $this->tmpData          =   addcslashes(htmlentities(trim($val)), $this->dataTESC);
                
                if(strlen($this->tmpData)>0){
                    $this->dataTRA[]    =   $this->tmpData;
                }
                else{
                    $this->dataTRA[]    =   "none";
                    $this->dataTRAER    +=1;
                }
            }
            
            return $this->dataTRA;
        }
        
        # get $_GET vars
        function getGetVals(){
            $this->dataTRA  =   array();
            foreach($_GET as $val){
                $this->tmpData          =   addcslashes(htmlentities(trim($val)), $this->dataTESC);
                
                if(strlen($this->tmpData)>0){
                    $this->dataTRA[]    =   $this->tmpData;
                }
                else{
                    $this->dataTRA[]    =   "none";
                    $this->dataTRAER    +=1;
                }
            }
            
            return $this->dataTRA;
        }
        
        # get admin by det
        function getUserByDetails($uemail,$upass){
            $this->upass    =   strrev(md5(strrev($upass)));
            $this->userData =   "none";
            $this->dt1Sql   =   "SELECT * FROM less_admins WHERE uemail='$uemail' AND upass='$this->upass' LIMIT 1";
            $this->dt1Query =   $this->mysqli->query($this->dt1Sql);
            $this->dt1Rows  =   $this->dt1Query->num_rows;
            if($this->dt1Rows==1){
                while($this->dt1Fetch= $this->dt1Query->fetch_assoc()){
                    $this->userData = $this->dt1Fetch;
                }
            }
            
            return $this->userData;
        }
        
        # get admin by Col
        function getUserByCol($col,$val){
            $this->fpval    =   $val;
            $this->fpvalER  =   0;
            
            $this->userData =   "none";
            $this->dt1Sql   =   "SELECT * FROM less_admins WHERE `$col`='$val' LIMIT 1";
            $this->dt1Query =   $this->mysqli->query($this->dt1Sql);
            $this->dt1Rows  =   $this->dt1Query->num_rows;
            if($this->dt1Rows==1){
                while($this->dt1Fetch= $this->dt1Query->fetch_assoc()){
                    $this->userData = $this->dt1Fetch;
                }
            }
            
            return $this->userData;
        }
        
        # add another admin
        function addAdmin($uname,$uemail,$upass,$utype){
            $this->funcStatus   =   "failed";
            $this->upass        =   strrev(md5(strrev($upass)));
            $this->dt2Sql       =   "INSERT INTO less_admins (uname,uemail,upass,ulmodi,utype) VALUES('$uname','$uemail','$this->upass','$this->tddate','$utype')";
            $this->dt2Query     =   $this->mysqli->query($this->dt2Sql);
            if($this->dt2Query){    $this->funcStatus   =   "done"; }
            
            return $this->funcStatus;
        }
        
        # update admin details
        function updateAdmin($col,$val){
            $this->funcStatus   =   "failed";
            $this->dt2Sql       =   "UPDATE less_admins SET `$col`='$val',ulmodi='$this->tddate' WHERE uid='$this->uid'";
            $this->dt2Query     =   $this->mysqli->query($this->dt2Sql);
            if($this->dt2Query){    $this->funcStatus   =   "done"; }
        }
        
        # get less / user db table rows
        function getDBTBrows($db,$tb){
            switch($tb){
                case "admins": $this->dt6Sql   =   "SELECT * FROM less_admins";                     break;
                default :      $this->dt6Sql   =   "SELECT * FROM site_content WHERE ctype='$tb'";  break;
            }
            
            if($db=="less"){    $this->dt6Query =   $this->mysqli->query($this->dt6Sql);        }
            else{               $this->dt6Query =   $this->userMysqli->query($this->dt6Sql);    }
            
            $this->dt6Rows  =   $this->dt6Query->num_rows;
            
            return $this->dt6Rows;
        }
        
        # 3 pass correction
        function correct3Pass($opass,$pass1,$pass2){
            $this->funcStatus   =   "failed";
            $this->oupass       =   strrev(md5(strrev($opass)));
            $this->upass1       =   strrev(md5(strrev($pass1)));
            $this->upass2       =   strrev(md5(strrev($pass2)));
            $this->userData =   $this->getUserByCol("uid",$this->uid);
            
            if($this->userData["upass"]== $this->oupass){
                if($this->oupass!=$this->upass1){
                    if($this->upass1==$this->upass2){
                            $this->funcStatus   =   "correct";
                    }else{  $this->funcStatus   =   "New passwords do not match"; }
                }else{      $this->funcStatus   =   "Old password can't be new password"; }
            }else{          $this->funcStatus   =   "wrong old user password"; }
            
            return $this->funcStatus;
        }
        
        #2 pass correct
        function correct2Pass($pass1,$pass2){
            $this->funcStatus   =   "failed";
            $this->upass1       =   strrev(md5(strrev($pass1)));
            $this->upass2       =   strrev(md5(strrev($pass2)));
            
            if($this->upass1==$this->upass2){
                    $this->funcStatus   =   "correct";
            }else{  $this->funcStatus   =   "New passwords do not match"; }
            
            return $this->funcStatus;
        }
        
        function hashedPass($pass){
            $this->funcDataTR   =   strrev(md5(strrev($pass)));
            
            return $this->funcDataTR;
        }
        
        function getData($tb,$cond){
            $this->dt8Sql       =   "SELECT * FROM `$tb` ".$cond;
            //echo $this->dt8Sql;
            $this->dt8Query     =   $this->userMysqli->query($this->dt8Sql);
            $this->dt8Rows      =   $this->dt8Query->num_rows;
            
            $this->bulkDataTR   =   array();
            if($this->dt8Rows>0){
                while($this->dt8Fetch   =   $this->dt8Query->fetch_assoc()){
                    $this->bulkDataTR[] =   $this->dt8Fetch;   
                }
            }
            
            return $this->bulkDataTR;
            
        }
        
        # get site content data rows
        function getPostData($oid,$type,$cond){
            switch($type){
                case "products":        $this->dt5Sql  =   "SELECT * FROM site_content WHERE ctype='product' AND cid='$oid' ".$cond." LIMIT 1";     break;
                case "trainings":       $this->dt5Sql  =   "SELECT * FROM site_content WHERE ctype='training' AND cid='$oid' ".$cond." LIMIT 1";    break;
                case "services":        $this->dt5Sql  =   "SELECT * FROM site_content WHERE ctype='service' AND cid='$oid' ".$cond." LIMIT 1";     break;
                case "site-slides":     $this->dt5Sql  =   "SELECT * FROM site_content WHERE ctype='site-slide' AND cid='$oid' ".$cond." LIMIT 1";  break;
                
                default :               $this->dt5Sql  =   "SELECT * FROM site_content WHERE ctype='product' AND cid='$oid' ".$cond." LIMIT 1";     break;
            }
           
            // echo $this->dt5Sql;
            
            $this->dt5Query     =   $this->userMysqli->query($this->dt5Sql);
            $this->dt5Rows      =   $this->dt5Query->num_rows;
            
            $this->funcDataTR   =   array();
            if($this->dt5Rows>0){
                while($this->dt5Fetch= $this->dt5Query->fetch_assoc()){
                    $this->funcDataTR   =   array();
                    foreach($this->dt5Fetch as $val){
                        $this->funcDataTR[] =   $val;
                    }
                }
            }
            
            return $this->funcDataTR;
                
        }
        
        function getFilesArrays($ia){
            $this->filesArray   = explode(",",$ia); 
            return $this->filesArray;
        }
        
        
    }
?>