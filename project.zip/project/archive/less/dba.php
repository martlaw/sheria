<?php

    class dba{
        
        private $mysqli;
        private $dataSql,$dataQuery,$dataRows,$dataFetch,$dataRowsTR;
        private $dtSql,$dtQuery,$dtRows,$dtFetch,$dtRowsTR;
        private $dt1Sql,$dt1Query,$dt1Rows,$dt1Fetch,$dt1RowsTR;
        private $dt2Sql,$dt2Query,$dt2Rows,$dt2Fetch,$dt2RowsTR;
        private $dt3Sql,$dt3Query,$dt3Rows,$dt3Fetch,$dt3RowsTR;
        private $dt4Sql,$dt4Query,$dt4Rows,$dt4Fetch,$dt4RowsTR;
        
        public  $dataTb,$dataCondition,$dataECode,$dataEMsg,$dataTR,$dataTRA;
        
        function __construct($mysqli,$tb,$cond) {
            
            $this->mysqli           =   $mysqli;
            $this->dataTb           =   $tb;
            $this->dataCondition    =   $cond;
            
            $this->dataTR           =   "none";
            $this->dataECode        =   0;
            $this->dataEMsg         =   "none";
            
            
        }
        
        function saveData(){
            $this->dataTR   =   "none";
            $this->dt1Sql   =   "INSERT INTO ".$this->dataCondition;
            //echo $this->dt1Sql;
            if($this->dt1Query  =   $this->mysqli->query($this->dt1Sql)){
                $this->dataTR   = $this->mysqli->insert_id;   
            }else{
                $this->dataECode        =   1;
                $this->dataEMsg         =   "Failed to save data";
            }
        }
        
        function getData(){
            $this->dataTR   =   "none";
            $this->dt2Sql   =   "SELECT * FROM `$this->dataTb` ".$this->dataCondition;
            $this->dt2Query =   $this->mysqli->query($this->dt2Sql);
            $this->dt2Rows  =   $this->dt2Query->num_rows;
            $this->dataTRA  =   array();
            if($this->dt2Rows>0){
                while($this->dt2Fetch   =   $this->dt2Query->fetch_assoc()){
                    $this->dataTRA[]    =   $this->dt2Fetch;
                }
            }else{
                $this->dataECode        =   1;
                $this->dataEMsg         =   "data not found";
            }
        }
        
        function getTBData($tb,$cond){
            $this->dataTb           =   $tb;
            $this->dataCondition    =   $cond;
            $this->dataTR           =   "none";
            $this->dt2Sql           =   "SELECT * FROM `$this->dataTb` ".$this->dataCondition;
            $this->dt2Query         =   $this->mysqli->query($this->dt2Sql);
            $this->dt2Rows          =   $this->dt2Query->num_rows;
            $this->dataTRA          =   array();
            if($this->dt2Rows>0){
                while($this->dt2Fetch   =   $this->dt2Query->fetch_assoc()){
                    $this->dataTRA[]    =   $this->dt2Fetch;
                }
            }else{
                $this->dataECode        =   1;
                $this->dataEMsg         =   "data not found";
            }
        }
        
        function getFreshData(){
            $this->dataTR   =   "none";
            $this->dt2Sql   =   $this->dataCondition;
            $this->dt2Query =   $this->mysqli->query($this->dt2Sql);
            $this->dt2Rows  =   $this->dt2Query->num_rows;
            $this->dataTRA  =   array();
            if($this->dt2Rows>0){
                while($this->dt2Fetch   =   $this->dt2Query->fetch_assoc()){
                    $this->dataTRA[]    =   $this->dt2Fetch;
                }
            }else{
                $this->dataECode        =   1;
                $this->dataEMsg         =   "data not found";
            }
        }
        
        
        function deleteData(){
            $this->dataTR   =   "none";
            $this->dt3Sql   =   "DELETE FROM `$this->dataTb` ".$this->dataCondition;
            $this->dt3Query =   $this->mysqli->query($this->dt3Sql);
            if($this->dt3Query){
                $this->dataTR           =   "done";   
            }else{
                $this->dataECode        =   1;
                $this->dataEMsg         =   "Failed to delete data";
            }
        }
    }

?>