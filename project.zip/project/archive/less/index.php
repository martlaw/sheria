<?php session_start(); ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title>LESS | HOME</title>
        <?php include'head.php'; ?>
        <?php include'dbconnect.php'; ?>
        <?php include'ifunc.php'; ?>
        <?php include'dba.php'; ?>
    </head>
    <body>
        <?php if((isset($_SESSION["less_login"]))&&($_SESSION["less_login"]==true)):?>
            <div class="dashboard">
                <?php include 'left-menu.php'; ?>
                <div id="right-content">
                    <?php include 'top-nav.php';  ?>
                    <div id="content-area">
                        <?php
                            $mtask  =   "none";
                            if(isset($_GET["task"])){
                                $mtask  =   htmlentities(trim($_GET["task"]));
                            }
                            
                            
                            $ifunc  =   new ifunc($mysqli);
                            $udata  =   $ifunc->getUserByCol("uid",$_SESSION["less_uid"]);
                        ?>
                        <?php include'home-menu.php';?>
                    </div>
                </div>
            </div>
        <?php else:?>
            <div class="loginPage">
                <div id="loginAR">
                    <form action="door.php?job=login" method="post">
                        <div id="less-logo"> <img src="http://edumek.com/cdn/brands/less.png"/> </div>
                        <input name="uname" type="text" id="uin" placeholder="userrname"/>
                        <input name="upass" type="password" id="uin" placeholder="password"/>
                        <div id="loginError">
                            <?php
                                if(isset($_GET["error"])&&isset($_GET["msg"])){ echo $_GET["msg"]; }
                                else if(isset($_GET["done"])&&isset($_GET["msg"])){ echo $_GET["msg"]; }
                            ?>
                        </div>
                        <button id="usub" type="submit">login</button>
                    </form>
                </div>
                <div id="cr"> &#xa9; <?php echo date("Y");?> less dashboards - edumek systems </div>
            </div>
        <?php endif;?>
    </body>
</html>