<?php
    class less{
        
        
        
        private $htmlData,$htmlTR,$dataTR,$dataTRA,$lessRegex,$regexMatches;
        private $tmpRegex,$tmpRegexData;
        
        
        function getLargeParagraph($data){
            $this->htmlData     =   strval(htmlspecialchars($data));
            $this->lessRegex    =   array();
            $this->lessRegex[0] =   "/(&lt;\s?p&gt\s?;)(([a-zA-Z0-9\_\+\;\&\,\+\:\;\=\?\[\]\@\#\|\^\*\%\!\$\'\"\`\~\%\(\)\.\s\\-]){140,1000})(\&lt;\s?\/p\s?\&gt;)/";
            $this->dataTR       =   "none";
            
            ini_set('pcre.backtrack_limit', 1000000);
            if(preg_match_all($this->lessRegex[0], $this->htmlData, $this->regexMatches,PREG_SET_ORDER)){
                $this->dataTR   =   $this->removeHtmlTag('p', $this->regexMatches[0][0]);
                $this->dataTR   =   $this->removeHtmlEntities('nbsp', strval($this->dataTR));
            }
            
            return $this->dataTR;
        }
        
        function removeHtmlTag($tag,$data){
            return preg_replace('/(&lt;)(\s?)(\/?)('.$tag.')(\s?)([a-zA-Z0-9\=\"\'\%;:_\s-]+)?(\/)?(&gt;)/', "", $data);
        }
        
        function removeUncompleteHtml($data){
            $this->tmpRegex =   '/(\<)[a-zA-Z0-9\&\=\"\'\%;:_\s-](\>)\s?(\<)([a-zA-Z0-9-]+)(\s?)(\>?)([a-zA-Z0-9\&\=\"\'\%;:_\s-]+)(\<\/)([a-zA-Z0-9\&\=\"\'\%;:_\s-])+$/';
            if(preg_match($this->tmpRegex, $data)){
                $this->tmpRegexData = preg_replace($this->tmpRegex,'', $data);
            }else{
                $this->tmpRegexData =   $data;
            }
            
            return $this->tmpRegexData;
        }
        
        function removeHtmlEntities($tag,$data){
            //echo str_replace($tag, "", $data);
            //echo str_replace("&;", "", str_replace($tag, "", $data));
            //echo str_replace('&amp;','BLEX',$data);
            //$this->tmpRegexData =   str_replace('nbsp','amp',$data);
            
            $this->tmpRegexData =   trim(strval(html_entity_decode(preg_replace('/\&[a-zA-Z]+((;[a-zA-Z]+)?)\;/', "", $data))));
            return $this->tmpRegexData;
            
            //echo str_replace('&amp;','BLESS',str_replace('nbsp','amp',$data));
            //return preg_replace('/\&'.$tag.'\;/','',$data);
            //return str_replace("\\t", "", html_entity_decode($data));
        }
    }
?>