<div id="top-nav">
    <div id="top-nav-search-AR">
        <input type="text" id="top-nav-search-IN" placeholder="enter keyword to search"/>
        <button id="top-nav-search-SB">search</button>
    </div>
    <a href="door.php?job=logout" class="btlink top-nav-logout">logout</a>
</div>