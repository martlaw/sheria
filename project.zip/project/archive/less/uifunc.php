<?php

    include 'dba.php';
    include 'less.php';

    class uifunc{
        private $uid,$upass,$userData,$ifunc;
        private $allMysqli,$userMysqli,$mysqli,$dataSql,$dataQuery,$dataRows,$dataFetch,
                $dtSql,$dtQuery,$dtRows,$dtFetch,
                $dt1Sql,$dt1Query,$dt1Rows,$dt1Fetch,
                $dt2Sql,$dt2Query,$dt2Rows,$dt2Fetch,
                $dt3Sql,$dt3Query,$dt3Rows,$dt3Fetch,
                $dt4Sql,$dt4Query,$dt4Rows,$dt4Fetch,
                $dt5Sql,$dt5Query,$dt5Rows,$dt5Fetch,
                $dt6Sql,$dt6Query,$dt6Rows,$dt6Fetch;
        
        # function data returned
        private $sdata,$ujob,$udata,$dataTR,$dataTRA,$tmpHtmlTR,$tmpData,$tmpUdata;
        private $loadTO,$goTOpage;
        public  $funcDataTR,$htmlTR;
        
        # important temp vars
        private $imageType;
        
        # files upload
        private $allFname,$fName,$fNewName,$ftmpName,$fLocation,$fExtension,$attachmentsER,$attachmentsERmsg,
                $folderLocation,$fileUploadError;
               
        
        # previous content
        private $ppid,$pptitle,$ppelink,$ppDlink,$ppcontent,$ppocontent,$ppoTitle,$ppimages;
                
        
        # time
        private $tddate,$tdtime,$tdyear;
        
        # image array
        private $filesArray;
        
        # DBA
        private $DBA,$DBAtable,$DBAcond,$DBAdataAR,$DBAdataJSON;
        
        # LESS
        private $less;
        
        function __construct($mysqli) {
            $this->allMysqli    =   $mysqli;
            $this->mysqli       =   $mysqli[0];
            $this->userMysqli   =   $mysqli[1];
            $this->uid          =   "none";
            $this->ifunc        =   new ifunc($this->allMysqli);
            $this->less         =   new less();
            
            if(isset($_SESSION["less_uid"])){   $this->uid          =   $_SESSION["less_uid"];  }
            
            $this->dataTESC     =   "'~!*,`\":";
            #time and dates
            $this->tddate       =   date("M d, Y - H:i");
            $this->tdtime       =   date("H:i");
            $this->tdyear       =   date("Y");
            
        }
        
        function setJob($ujob,$udata){
            $this->ujob     =   $ujob;
            $this->udata    =   $udata;
            $this->loadTO   =   "none";
            
            switch ($this->ujob){
                case "add-to-judgements":   $this->goTOpage    =   "menu.php?task=".$this->ujob;    $this->addTO();                                                                         break;
                case "add-to-articles":     $this->goTOpage    =   "menu.php?task=".$this->ujob;    $this->addTO();                                                                         break;
                case "add-to-categories":   $this->goTOpage    =   "menu.php?task=".$this->ujob;    $this->addTO();                                                                         break;
                case "notify-user":         $this->goTOpage    =   "menu.php?task=".$this->ujob;    $this->addTO();                                                                         break;
                case "site-slides":         $this->goTOpage    =   "menu.php?task=".$this->ujob;    $this->addTO();                                                                         break;
            }
            
            return $this->loadTO;
        }
        
        function addTO(){
            
            if($this->ujob=="add-to-judgements"){
                $this->saveFileWithText("site-content");
                $this->DBAtable =   "judgements";
                $this->tmpUdata =   $_POST['judgement'];
                $this->tmpData  =   $this->less->getLargeParagraph($this->tmpUdata);
                $this->tmpData  =   substr($this->tmpData,0,250)."....";
                $this->DBAcond  =   $this->DBAtable."(jtitle,jdate,jcategory,jsnippet,jcontent,jfiles) VALUES('".$this->udata[0]."','".$this->udata[1]."','".$this->udata[2]."','".$this->tmpData."','".$this->tmpUdata."','".$this->allFname."')";
                $this->DBA      =   new dba($this->userMysqli, $this->DBAtable, $this->DBAcond);
                $this->DBA->saveData();
                if($this->DBA->dataECode==0){   $this->loadTO   =   $this->goTOpage."&&done=1&&msg=".urlencode("Data has been saved");}
                else{                           $this->loadTO   =   $this->goTOpage."&&error=1&&msg=".urlencode($this->DBA->dataEMsg);}
                
            }
            elseif($this->ujob=="add-to-articles"){
                $this->saveFileWithText("site-content");
                $this->DBAtable =   "web_data";
                $this->DBAcond  =   $this->DBAtable."(dtype,udata2,udata1,udata3,udata4) VALUES('article','".$this->udata[0]."','".$this->udata[1]."','".$this->allFname."','$this->tddate')";
                $this->DBA      =   new dba($this->userMysqli, $this->DBAtable, $this->DBAcond);
                $this->DBA->saveData();
                if($this->DBA->dataECode==0){   $this->loadTO   =   $this->goTOpage."&&done=1&&msg=".urlencode("Data has been saved");}
                else{                           $this->loadTO   =   $this->goTOpage."&&error=1&&msg=".urlencode($this->DBA->dataEMsg);}
            }
            elseif($this->ujob=="add-to-categories"){
                $this->DBAtable =   "web_data";
                $this->tmpData  =   strtolower($this->udata[0]);
                $this->DBAcond  =   $this->DBAtable."(dtype,udata1) VALUES('category','$this->tmpData')";
                $this->DBA      =   new dba($this->userMysqli, $this->DBAtable, $this->DBAcond);
                $this->DBA->saveData();
                if($this->DBA->dataECode==0){   $this->loadTO   =   $this->goTOpage."&&done=1&&msg=".urlencode("Data has been saved");}
                else{                           $this->loadTO   =   $this->goTOpage."&&error=1&&msg=".urlencode($this->DBA->dataEMsg);}
            }

        }
        
        function editContent(){
            
        }
        
        # MAJOR ONE FUNCTIONS
        # 
        
        # upload file with text
        function saveFileWithText($fileLocation){
            $this->allFname         =   "";
            $this->attachmentsER    =   0;
            $this->loadTO             =   "none";
            $this->folderLocation   =   $fileLocation;
            
            
            if(isset($_FILES["attachments"]["tmp_name"])&&(count($_FILES["attachments"]["tmp_name"])>0) &&(strlen($_FILES["attachments"]["name"][0])>0)){
                foreach($_FILES["attachments"]["name"] as $key => $val){
                    if($_FILES['attachments']['error'][$key] == 4){
                        continue;
                    }
                    
                    if($_FILES['attachments']['error'][$key] == 0){
                        $this->fName        = str_replace(" ","-",$_FILES["attachments"]["name"][$key]);
                        $this->ftmpName     =   $_FILES["attachments"]["tmp_name"][$key];

                        $this->fExtension   =   strtolower(substr($this->fName, strrpos($this->fName,".")+1));
                        $this->fNewName     =   addcslashes(htmlentities(time()."-".$this->uid."-"."less-img".$this->fName), $this->dataTESC);
                        $this->fLocation    =   $this->folderLocation."/".$this->fNewName;

                        if(move_uploaded_file($this->ftmpName, $this->fLocation)){
                            $this->allFname .=  $this->fLocation.",";
                            //echo $this->fLocation."<br>";
                        }
                        else{   
                            $this->loadTO =   $this->goTOpage."oid=".$this->oid."&&error=1&&msg=".urlencode("Failed to upload your attachments");   
                            $this->attachmentsER    =   2;
                        }
                    }
                }
                
                $this->allFname =   substr($this->allFname,0, strlen($this->allFname)-1);
                
            }else{ $this->attachmentsER     =   1; }
            
            
            # check attachments
            if($this->attachmentsER!=0){    $this->allFname =   "none"; }
            
            # save status
            if($this->loadTO=="none"){              }
        }
        
        # upload single file
        function uploadFile($tmpName,$location){
            if(move_uploaded_file($tmpName,$location)){
                return "tayar";
            }else{
                return "bado";
            }
        }
        
        # upload file caption | details
        function uploadFileDetails(){
            switch($this->ujob){
                case "": $this->dtbreak;
            }
        }
        
        
    }
?>