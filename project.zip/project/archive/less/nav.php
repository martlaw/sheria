<div class="header">
    <div id="nav">
        <div id="licon"> <img src="icons/icon.png"/> </div>
        <div id="rightBTS">
            <?php if(isset($_SESSION["pico_login"])&&$_SESSION["pico_login"]==true):?>
                <a href="index.php" class="btlink wbg">Home</a>
                <a href="door.php?job=logout" class="btlink wobg">Logout</a>
            <?php else:?>
                <a href="index.php?action=register" class="btlink wbg">Register</a>
                <a href="index.php?action=login" class="btlink wobg">Login</a>
            <?php endif;?>
        </div>
        <?php if(isset($_SESSION["pico_login"])&&$_SESSION["pico_login"]==true):?>
            <!--<div id="navs">
                <input type="text" id="navsin"/>
                <button id="navssub">search</button>
            </div>-->
        <?php endif;?>
        <div class="clr"></div>
    </div>
</div>