<div class="statusBar">
    <?php
    
        if(isset($_GET["error"])&&isset($_GET["msg"])){         echo '<div id="errorStatus"> <div id="statusIcon"><img src="icons/w-error-icon.png"/></div> '.$_GET["msg"].'</div>'; }
        else if(isset($_GET["done"])&&isset($_GET["msg"])){     echo '<div id="doneStatus"> <div id="statusIcon"><img src="icons/w-done-icon.png"/></div> '.$_GET["msg"].'</div>'; }
    ?>
    
</div>