<?php
    session_start();
    include 'dbconnect.php';
    include 'ifunc.php';
    
    class door{
        private $uid,$udata,$ulevel,$ifunc;
        private $allMysqli,$mysqli,$dataSql,$dataQuery,$dataRows,$dataFetch,
                $dtSql,$dtQuery,$dtRows,$dtFetch,
                $dt2Sql,$dt2Query,$dt2Rows,$dt2Fetch,
                $sdata,$sdata1,$sdata2;
        
        private $pdataAR,$pdataARER,$dataTESC;
        private $upass;
        private $job,$goTO;
        
        
        function __construct($mysqli) {
            $this->allMysqli    =   $mysqli;
            $this->mysqli       =   $mysqli[0];
            $this->dataTESC     =   "'~!*`\":";
            
            $this->uid          =   "none";
            if(isset($_SESSION["less_uid"])){   $this->uid          =   $_SESSION["less_uid"];  }
            
            $this->job          =   htmlentities(trim($_GET["job"]));
            $this->ifunc        =   new ifunc($this->allMysqli);
            $this->pdataAR      =   $this->ifunc->getPostVals();
            $this->pdataARER    =   $this->ifunc->dataTRAER;
            
            //print_r($this->pdataAR);
            
            if($this->job=="logout"){
                $this->closeDoor();
            }
            else{
                if($this->pdataARER==0){
                    switch($this->job){
                        case "login":       $this->openDoor();      break;
                        case "register":    $this->createUser();    break;
                    }
                }
                else{   $this->goTO =   "index.php?action=".$this->job."&&error=1&&msg=".urlencode("Please Fill all fields"); }
            }
        }
        
        function openDoor(){
            
            $this->udata    =   $this->ifunc->getUserByDetails($this->pdataAR[0],$this->pdataAR[1]);
            if($this->udata!="none"){
                $_SESSION["less_login"]     =   true;
                $_SESSION["less_uid"]       =   $this->udata["uid"];
                $_SESSION["less_uemail"]    =   $this->udata["uemail"];
                $_SESSION["less_uname"]     =   $this->udata["uname"];
                $_SESSION["less_utype"]     =   $this->udata["utype"];
                $_SESSION["less_utype"]     =   $this->udata["ulmodi"];
                
                        $this->goTO =   "index.php?done=1&&msg=".urlencode("Welcome, you have successful logged in");
            }
            else{       $this->goTO =   "index.php?action=".$this->job."&&error=1&&msg=".urlencode("Wrong username or password");}
        }
        
        function closeDoor(){
            $_SESSION["less_login"]     =   false;
            session_destroy();
            $this->goTO =   "index.php?done=1&&msg=".urlencode("you have successful logged out");
        }
        
        function output(){
            header("Location: $this->goTO");
        }
    }
    
    $door   =   new door($mysqli);
    $door->output();
?>