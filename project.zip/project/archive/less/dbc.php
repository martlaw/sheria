<?php

    $dbhost =   "localhost";
    $dbuser =   "root";
    $dbpass =   "";
    
    $dbname     =   array();
    $dbname[0]  =   "less_dashboard";
    $dbname[1]  =   "";
    $dbname[2]  =   "";
    
    
    $mysqli     =   array();
    $mysqli[0]  =   new mysqli($dbhost,$dbuser,$dbpass,$dbname[0]);
    $mysqli[1]  =   new mysqli($dbhost,$dbuser,$dbpass,$dbname[1]);
    $mysqli[2]  =   new mysqli($dbhost,$dbuser,$dbpass,$dbname[2]);

?>