$(document).ready(function(){
    // post attachment
    var attachmentButton    =   $(".uinarea input#attachIn");
    var attachmentsArea     =   $(".uinarea div#attachments");
    var attachmentsStatus   =   $("input.attachments-status");
    
    // searching
    var inlineSearchIN      =   $(".searchAR input#consin");
    var inlineSearchBT      =   $(".searchAR button#conssub");
    
    
    // mcat
    var leftMcat            =   $(".dashboard div#left-mcat");
    
    
    
        attachmentButton.change(function(){
            attachmentsArea.html("loading images");
            if(this.files){
                attachmentsStatus.attr("value","zipo");   
                var filesNum        =   this.files.length;
                    attachmentsArea.html("")
                    for(var i=0;i<filesNum;i++){
                        var areader     =   new FileReader();
                        areader.onload  =   function(e){
                            attachmentsArea.append('<div id="attachment" style="background:url('+e.target.result+');"></div>');
                        };
                        areader.readAsDataURL(this.files[i]); 
                    }
            }
        });
        
        // search submit
        inlineSearchBT.click(function(){
            var keyword =   inlineSearchIN.val().trim();
                if(keyword.length>0){
                    window.location.href    =   "index.php?results=true&&keyword="+encodeURIComponent(keyword);
                }else{
                    inlineSearchIN.focus().css("background","#fffabf");
                }
        });
        
        // mcat clicked
        leftMcat.click(function(){
            var task    =   $(this).attr("data-task");
                window.location.href    =   "menu.php?task="+task;
        });
});