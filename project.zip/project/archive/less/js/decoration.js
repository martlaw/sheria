$(document).ready(function(){
    var firstInput  =   $(".uinarea input:first");
    var lrFinput    =   $(".cards div#lr-card input:first");
    var ppicSel     =   $(".uinarea input#file-in");
    var ppicImg     =   $(".uinarea img#ap-pic-img");
    
    
    
        setInterval(resizer,100);
        firstInput.focus();
        lrFinput.focus();
    
        // focus on the first input


        function resizer(){
            var profilePic  =   $(".cards div#profilePic");
                
                profilePic.css("height",profilePic.innerWidth()+"px");
                profilePic.css("background-size","cover");
                
            var attachment  =   $(".uinarea div#attachment");
                attachment.css("height",attachment.innerWidth()+"px");
                attachment.css("background-size","cover");
                
            var postPpic    =   $(".posts div#post-ppic");
                postPpic.css("height",postPpic.innerWidth()+"px");
                postPpic.css("background-size","cover");
                
            var ppostPic    =   $(".posts div#pimage");
                ppostPic.css("height",ppostPic.innerWidth()+"px");
                ppostPic.css("background-size","cover");
        }
        
        ppicSel.change(function(){
            
            console.log("image selected");
            if(this.files&&this.files[0]){
                var ireader =   new FileReader();
                    ireader.onload  =   function(e){
                        ppicImg.attr("src",e.target.result);
                    };
                    ireader.readAsDataURL(this.files[0]);
            }
        });
});