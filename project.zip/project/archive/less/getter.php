<?php
    include 'dbconnect.php';
    include 'ifunc.php';
    include 'uifunc.php';

    class getter{
        private $uid,$upass;
        public  $ifunc;
        private $allMysqli,$userMysqli,$mysqli,$dataSql,$dataQuery,$dataRows,$dataFetch,
                $dtSql,$dtQuery,$dtRows,$dtFetch,
                $dt1Sql,$dt1Query,$dt1Rows,$dt1Fetch,
                $dt2Sql,$dt2Query,$dt2Rows,$dt2Fetch,
                $dt3Sql,$dt3Query,$dt3Rows,$dt3Fetch,
                $dt4Sql,$dt4Query,$dt4Rows,$dt4Fetch,
                $dt5Sql,$dt5Query,$dt5Rows,$dt5Fetch,
                $dt6Sql,$dt6Query,$dt6Rows,$dt6Fetch;
        
        private $oupass,$upass1,$upass2;
        
        # function returns
        private $funcDataTR,$funcStatus,$bulkDataTR,$funcHTMLtr,$htmlTR,$parentDir;
        
        #time
        private $tddate,$tdtime,$tdyear;
        
        # site images
        public $siteImages;
        
        function __construct($mysqli) {
            $this->allMysqli    =   $mysqli;
            $this->mysqli       =   $mysqli[0];
            $this->userMysqli   =   $mysqli[1];
            $this->ifunc        =   new ifunc($mysqli);
            $this->funcHTMLtr   =   '';
        }
        
        function getSiteContent($scon,$cond){
            $this->dt6Sql       =   "SELECT * FROM site_content WHERE ctype='$scon' ".$cond;
            $this->dt6Query     =   $this->userMysqli->query($this->dt6Sql);
            $this->dt6Rows      =   $this->dt6Query->num_rows;
            
            $this->funcDataTR   =   array();
            if($this->dt6Rows>0){
                while($this->dt6Fetch   =   $this->dt6Query->fetch_assoc()){
                    $this->funcDataTR[] =   $this->dt6Fetch;
                }
            }
            
            return $this->funcDataTR;
        }
        
        function getImages($cond){
            $this->bulkDataTR   =   $this->ifunc->getData("images",$cond);
            $this->siteImages   =   $this->bulkDataTR;
            
        }
        
    }
?>