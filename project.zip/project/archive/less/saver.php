<?php
    session_start();
    date_default_timezone_set("Africa/Dar_es_Salaam");
    
    include 'dbconnect.php';
    include 'ifunc.php';
    include 'uifunc.php';
    
    
    class saver{
        private $uid,$oid,$udata,$ulevel,$ifunc,$uifunc;
        private $allMysqli,$userMysqli,$mysqli,$dataSql,$dataQuery,$dataRows,$dataFetch,$dataQueryStatus,
                $dtSql,$dtQuery,$dtRows,$dtFetch,$dtQueryStatus,
                $dt1Sql,$dt1Query,$dt1Rows,$dt1Fetch,
                $dt2Sql,$dt2Query,$dt2Rows,$dt2Fetch,
                $dt3Sql,$dt3Query,$dt3Rows,$dt3Fetch,
                $dt4Sql,$dt4Query,$dt4Rows,$dt4Fetch,
                $dt5Sql,$dt5Query,$dt5Rows,$dt5Fetch,
                $dt6Sql,$dt6Query,$dt6Rows,$dt6Fetch,
                $sdata,$sdataV1,$sdataV2,$sdataV3,$sdataVAR;
        
        private $pdataAR,$pdataARER,$gdataAR,$gdataARER,$dataTESC;
        private $job,$settingsTask,$settingsTaskER,$settingsTaskMsg,$goTO,$goTOpage;
        
        #post and comments
        private $postType;
        
        #pics upload
        private $allFname,$fName,$fNewName,$ftmpName,$fLocation,$fExtension,$attachmentsER,$attachmentsERmsg;
        
        #time
        private $tddate,$tdtime,$tdyear;
        
        private $DBA,$DBAtable,$DBAcond,$DBAdataAR,$DBAdataJSON;
        
        function __construct($mysqli) {
            $this->allMysqli    =   $mysqli;
            $this->mysqli       =   $mysqli[0];
            $this->userMysqli   =   $mysqli[1];
            
            $this->uid          =   "none";
            if(isset($_SESSION["less_uid"])){   $this->uid          =   $_SESSION["less_uid"];  }
            
            $this->dataTESC     =   "'~!*,`\":";
            $this->oid          =   "none";
            $this->job          =   "none";
            
            if(isset($_GET["oid"])){    $this->oid  =   htmlentities(trim($_GET["oid"]));   }
            if(isset($_GET["job"])){    $this->job  =   htmlentities(trim($_GET["job"]));   }
            
            #less important function
            $this->ifunc    =   new ifunc($this->allMysqli);
            
            #user important function
            $this->uifunc   =   new uifunc($this->allMysqli);
            
            #time and dates
            $this->tddate       =   date("M d, Y - H:i");
            $this->tdtime       =   date("H:i");
            $this->tdyear       =   date("Y");
            
            # get post data
            $this->pdataAR      =   $this->ifunc->getPostVals();
            $this->pdataARER    =   $this->ifunc->dataTRAER;
            
            # get GET vals
            $this->gdataAR      =   $this->ifunc->getGetVals();
            $this->gdataARER    =   $this->ifunc->dataTRAER;
            
            
            
            
            
            # for function with post post metohd
            if($this->pdataARER==0){
                
                if($this->job=="settings"){         $this->adminSettings(); }
                else if($this->job=="add-admin"){   $this->addAdmin();      }
                else{ 
                    # user platform action
                    $this->goTO =   $this->uifunc->setJob($this->job,$this->pdataAR);
                }
            }else{ $this->goTO =   "menu.php?task=".$this->job."&&error=1&&msg=".urlencode("Please fill all fields"); }
            
            
            # for function with get method
            if($this->job=="deleter"){  $this->dataDeleter();   }
        }
        
        function adminSettings(){
            $this->settingsTask     =   $this->pdataAR[0];
            $this->settingsTaskER   =   0;
            $this->settingsTaskMsg  =   "";
            
            if($this->settingsTask=="upass"){
                $this->settingsTaskMsg  =  $this->ifunc->correct3Pass($this->pdataAR[1],$this->pdataAR[2],$this->pdataAR[3]); 
                if($this->settingsTaskMsg=="correct"){
                    
                        $this->ifunc->updateAdmin($this->settingsTask,$this->pdataAR[2]);
                        $this->goTO =   "menu.php?task=".$this->job."&&error=1&&msg=".urlencode("password has been changed");
                        
                }else{  $this->goTO =   "menu.php?task=".$this->job."&&error=1&&msg=".urlencode($this->settingsTaskMsg); }
            }
            else if($this->settingsTask=="uemail"){
                if($this->ifunc->getUserByCol($this->settingsTask,$this->pdataAR[1])=="none"){
                    
                        $this->ifunc->updateAdmin($this->settingsTask,$this->pdataAR[1]);
                        $this->goTO =   "menu.php?task=".$this->job."&&error=1&&msg=".urlencode("email has been changed");
                    
                }else{  $this->goTO =   "menu.php?task=".$this->job."&&error=1&&msg=".urlencode("Email alredy in use"); }
            }
            else{
                        $this->ifunc->updateAdmin($this->settingsTask,$this->pdataAR[1]);
                        $this->goTO =   "menu.php?task=".$this->job."&&error=1&&msg=".urlencode("data has been modified");
            }
            
        }
        
        function addAdmin(){
            if($this->ifunc->getUserByCol("uemail",$this->pdataAR[1])=="none"){
                $this->settingsTaskMsg  =   $this->ifunc->correct2Pass($this->pdataAR[2],$this->pdataAR[3]);
                if($this->settingsTaskMsg=="correct"){
                    
                        $this->ifunc->addAdmin($this->pdataAR[0],$this->pdataAR[1],$this->pdataAR[2],$this->pdataAR[2]);
                        $this->goTO =   "menu.php?task=".$this->job."&&error=1&&msg=".urlencode("new admin has been added ");
                        
                }else{  $this->goTO =   "menu.php?task=".$this->job."&&error=1&&msg=".urlencode($this->settingsTaskMsg); }
            }else{      $this->goTO =   "menu.php?task=".$this->job."&&error=1&&msg=".urlencode("Email alredy in use"); }
        }
        
        function output(){
            //echo $this->goTO;
            header("Location: $this->goTO");
        }
        
    } 
    
    $saver  =   new saver($mysqli);
    $saver->output();
    
?>