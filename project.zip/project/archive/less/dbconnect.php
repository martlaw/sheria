<?php
    $dbhost =   "localhost";
    $dbuser =   "root";
    $dbpass =   "";
    
    $dbname     =   array();
    $dbname[0]  =   "less_dashboard";
    $dbname[1]  =   "legal_bank";
    
    $mysqli     =   array();
    $mysqli[0]  =   new mysqli($dbhost,$dbuser,$dbpass,$dbname[0]); # core database
    $mysqli[1]  =   new mysqli($dbhost,$dbuser,$dbpass,$dbname[1]); # user database
    
    
    # databases arrays
    $dbnameAR       =   array();
    $dbnameAR[0]    =   "less_dashboard";
    $dbnameAR[1]    =   "legal_bank";
    $dbnameAR[2]    =   "";
    
    # mysqli arrays
    $mysqliAR       =   array();
    $mysqliAR[0]    =   new mysqli($dbhost,$dbuser,$dbpass,$dbnameAR[0]);
    $mysqliAR[1]    =   new mysqli($dbhost,$dbuser,$dbpass,$dbnameAR[1]);
    $mysqliAR[2]    =   new mysqli($dbhost,$dbuser,$dbpass,$dbnameAR[2]);
?>