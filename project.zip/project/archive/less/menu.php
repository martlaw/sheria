<?php session_start(); ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title>LESS | HOME</title>
        <?php include'head.php'; ?>
        <?php include'dbconnect.php'; ?>
        <?php include'ifunc.php'; ?>
        <?php include'uifunc.php'; ?>
    </head>
    <body>
        <?php if((isset($_SESSION["less_login"]))&&($_SESSION["less_login"]==true)):?>
            <div class="dashboard">
                <?php include 'left-menu.php'; ?>
                
                <div id="right-content">
                    <?php include 'top-nav.php'; ?>
                    <div id="content-area">
                        <?php include 'status-bar.php'; ?>
                        <?php
                            $mtask  =   "none";
                            if(isset($_GET["task"])){
                                $mtask  =   htmlentities(trim($_GET["task"]));
                            }
                            
                            
                            $ifunc  =   new ifunc($mysqli);
                            $uifunc =   new uifunc($mysqli);
                            $udata  =   $ifunc->getUserByCol("uid",$_SESSION["less_uid"]);
                            
                            $pedit  =   "false";
                            $poid   =   "none";
                            $potype =   "none";   
                            
                            if(isset($_GET["edit"])&&isset($_GET["oid"])){ $pedit   =   $_GET["edit"];  $poid   =   $_GET["oid"]; }
                            switch($mtask){
                                case "add-to-products":     $potype =   "products";         break;
                                case "add-to-trainings":    $potype =   "trainings";        break;
                                case "add-to-courses":      $potype =   "courses";          break;
                                case "add-to-services":     $potype =   "services";         break;
                                case "site-slides":         $potype =   "site-slides";      break;
                                case "view-applications":   $potype =   "applications";     break;
                                case "view-orders":         $potype =   "orders";           break;
                                default:                    $potype =   "products";         break;
                            }
                            
                            $pdata  =   array();
                            
                            #set values to null
                            for($i=0;$i<100;$i++){ $pdata[$i]  =   ""; }
                            
                            # get db vals
                            $dbpdata    =   array();
                            //if($mtask!="home"){ $dbpdata    =   $uifunc->getPostData($poid,$potype,""); }
                                
                            
                            # assign values
                            if(count($dbpdata)>0){
                                for($i=0;$i<count($dbpdata);$i++){ $pdata[$i]  =   $dbpdata[$i]; }
                            }
                            
                        ?>
                        
                        
                        <div class="uinarea">
                            <?php if($mtask=="home"):?>
                                <?php include'home-menu.php';?>
                            
                            
                            <!-- ADD TO JUDGEMENTS -->
                            <?php elseif($mtask=="add-to-judgements"): ?>
                                <div id="lbheading"><?php if($pedit=="true"){ echo "Edit";} else{ echo "Add"; }?> Judgement content</div>
                                <form action="saver.php?job=<?php if($pedit=="true"){ echo "edit-content";} else{ echo $mtask; }?>" method="post" enctype="multipart/form-data">
                                    <?php if($pedit=="true"):?>
                                        <input type="hidden" name="post-oid" value="<?php echo $poid; ?>"/>
                                        <input type="hidden" name="post-otype" value="<?php echo $potype; ?>"/>
                                    <?php endif;?>
                                    <div id="ndatarow">
                                        <input type="text" name="judgement-title" id="fuin" value="<?php echo $pdata[1]; ?>" placeholder="Judgement title"/>
                                    </div>
                                    <div id="ndatarow">
                                        <input type="text" name="judgement-date" id="fuin" value="<?php echo $pdata[2]; ?>" placeholder="Date released"/>
                                    </div>
                                    <div id="ndatarow">
                                        <input type="text" name="judgement-category" id="fuin" value="<?php echo $pdata[2]; ?>" placeholder="Judgement category"/>
                                    </div>
                                    <div id="ndatarow">
                                        <textarea id="fuin" name="judgement"  placeholder="Judgement content"><?php echo $pdata[2]; ?></textarea>
                                    </div>
                                    <?php if($pedit!="true"):?>
                                        <div id="attachments"> <!-- attachments goes here --> </div>
                                    <?php endif;?>
                                    <div class="rseter">
                                        <button id="submit">save</button>
                                    </div>
                                </form>
                            <!-- END ADD TO JUDGEMENTS-->
                            
                            
                            
                            <!-- ADD TO ARTICLES-->
                            <?php elseif($mtask=="add-to-articles"): ?>
                                <div id="lbheading"><?php if($pedit=="true"){ echo "Edit";} else{ echo "Add"; }?> Article content</div>
                                <form action="saver.php?job=<?php if($pedit=="true"){ echo "edit-content";} else{ echo $mtask; }?>" method="post" enctype="multipart/form-data">
                                    <?php if($pedit=="true"):?>
                                        <input type="hidden" name="post-oid" value="<?php echo $poid; ?>"/>
                                        <input type="hidden" name="post-otype" value="<?php echo $potype; ?>"/>
                                    <?php endif;?>
                                    <div id="ndatarow">
                                        <input type="text" name="title" id="fuin" value="<?php echo $pdata[1]; ?>" placeholder="Article title"/>
                                    </div>
                                    <div id="ndatarow">
                                        <textarea id="fuin" name="content"  placeholder="Article content"><?php echo $pdata[2]; ?></textarea>
                                    </div>
                                    <?php if($pedit!="true"):?>
                                        <div id="attachments"> <!-- attachments goes here --> </div>
                                    <?php endif;?>
                                    <div class="rseter">
                                        <?php if($pedit!="true"):?>
                                            <div id="attach">
                                                <div id="attachIco"><img src="icons/attachment.png"/></div>
                                                <input type="file" id="attachIn" name="attachments[]" multiple="multiple" accept="image/*"/>
                                                <div id="attachTitle">select image(s)</div>
                                            </div>
                                        <?php endif;?>
                                        <button id="submit">save</button>
                                    </div>
                                </form>
                            <!-- END ADD TO ARTICLES -->
                            
                            
                            <!-- ADD TO CATEGORY-->
                            <?php elseif($mtask=="add-to-categories"): ?>
                                <div id="lbheading"><?php if($pedit=="true"){ echo "Edit";} else{ echo "Add"; }?> Category content</div>
                                <form action="saver.php?job=<?php if($pedit=="true"){ echo "edit-content";} else{ echo $mtask; }?>" method="post" enctype="multipart/form-data">
                                    <?php if($pedit=="true"):?>
                                        <input type="hidden" name="post-oid" value="<?php echo $poid; ?>"/>
                                        <input type="hidden" name="post-otype" value="<?php echo $potype; ?>"/>
                                    <?php endif;?>
                                    <div id="ndatarow">
                                        <input type="text" name="category" id="fuin" value="<?php echo $pdata[4]; ?>" placeholder="Category name"/>
                                    </div>
                                    <div class="rseter">
                                        <button id="submit">save</button>
                                    </div>
                                </form>
                            <!-- END ADD TO CATEGORY -->
                            
                            <!-- NOTIFY USERS-->
                            <?php elseif($mtask=="notify-users"): ?>
                                <div id="lbheading">Notify Users</div>
                                <form action="saver.php?job=<?php if($pedit=="true"){ echo "edit-content";} else{ echo $mtask; }?>" method="post" enctype="multipart/form-data">
                                    
                                    <div id="ndatarow">
                                        <select id="fuin" name="utype">
                                            <option value="">User type</option>
                                            <option value="super">  Premium user </option>
                                            <option value="normal"> Normal user  </option>
                                        </select>
                                    </div>
                                    
                                    <div id="ndatarow">
                                        <select id="fuin" name="ctype">
                                            <option value="">Message type</option>
                                            <option value="nmsg">  Normal Message </option>
                                            <option value="bmsg">  Bulk Message   </option>
                                            <option value="email"> Email Message  </option>
                                        </select>
                                    </div>
                                    
                                        
                                    <div id="ndatarow">
                                        <textarea id="fuin" name="msg"  placeholder="Message"><?php echo $pdata[2]; ?></textarea>
                                    </div>
                                    <div class="rseter">
                                        <button id="submit">notify</button>
                                    </div>
                                </form>
                            <!-- END NOTIFY USERS -->
                            
                            <?php elseif($mtask=="add-admin"): ?>
                                <div id="lbheading">Add admin</div>
                                <form action="saver.php?job=add-admin" method="post" enctype="multipart/form-data">
                                    <div id="ndatarow">
                                        <input type="text" id="muin" name="uname" placeholder="admin name"/>
                                        <input type="text" id="muin" name="uemail" placeholder="admin email"/>
                                    </div>
                                    <div id="ndatarow">
                                        <input type="password" id="muin" name="pass1" placeholder="new password"/>
                                        <input type="password" id="muin" name="pass2" placeholder="retype password"/>
                                    </div>
                                    <div id="ndatarow">
                                        <select id="fuin" name="atype">
                                            <option value="">Admin type</option>
                                            <option value="super">super admin</option>
                                            <option value="normal">normal admin</option>
                                        </select>
                                    </div>
                                    <div class="rseter">    <button id="submit">add</button> </div>
                                </form>
                                
                            <?php elseif($mtask=="settings"): ?>
                                <div id="lbheading">Full name</div>
                                <form action="saver.php?job=settings" method="post" enctype="multipart/form-data">
                                    <div id="ndatarow">
                                        <input type="hidden" name="tbc" value="uname"/>
                                        <input type="text" name="uname" id="fuin" value="<?php echo $udata["uname"]; ?>" placeholder="enter new name"/>
                                    </div>
                                    <div class="rseter">    <button id="submit">save</button> </div>
                                </form>
                                <div id="lbheading">Email</div>
                                <form action="saver.php?job=settings" method="post" enctype="multipart/form-data">
                                    <div id="ndatarow">
                                        <input type="hidden" name="tbc" value="uemail"/>
                                        <input type="text" name="uemail" id="fuin" value="<?php echo $udata["uemail"]; ?>" placeholder="enter new email"/>
                                    </div>
                                    <div class="rseter">    <button id="submit">save</button> </div>
                                </form>
                                <div id="lbheading">Password</div>
                                <form action="saver.php?job=settings" method="post" enctype="multipart/form-data">
                                    <div id="ndatarow">
                                        <input type="hidden" name="tbc" value="upass"/>
                                        <input type="password" name="opass" id="fuin" placeholder="old password"/>
                                    </div>
                                    <div id="ndatarow">
                                        <input type="password" id="muin" name="pass1" placeholder="new password"/>
                                        <input type="password" id="muin" name="pass2" placeholder="retype password"/>
                                    </div>
                                    <div class="rseter">    <button id="submit">save</button> </div>
                                </form>
                            <?php endif;?>
                        </div>
                    </div>
                </div>
            </div>
        <?php else:?>
        <script type="text/javascript">
            $(document).ready(function(){
                window.location.href    =   "index.php";
            });
        </script>
        <?php endif;?>
    </body>
</html>