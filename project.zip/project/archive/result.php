<?php session_start(); ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title>Legal Bank | Results</title>
        <?php include'head.php'; ?>
    </head>
    <body>
        <?php 
            include 'nav.php';
            include 'less/dba.php';
            include 'less/less.php';
            
            $action =   "register";
            if(isset($_GET["action"])){
                $action = htmlentities($_GET["action"]);
            }
        ?>
        <?php if((isset($_SESSION["tls_login"]))&&($_SESSION["tls_login"]==true)):?>
            <div class="cards">
                <?php 
                    include 'dbconnect.php';
                    include 'ifunc.php';
                    $ifunc  =   new ifunc($mysqli);
                ?>
                <div id="b-leftCards">
                    <div class="searchAR">
                        <div id="cons">
                            <input type="text" id="consin" class="inline-search-in" placeholder="Enter case name | keyword"/>
                            <button id="conssub" class="inline-search-sub">search</button>
                        </div>
                    </div>
                    <div class="posts">
                        <?php
                            if(isset($_GET["result"])&&isset($_GET["id"])&&($_GET["result"]==true)){
                                $keyword    =   "";
                                
                                if(isset($_GET["keyword"])){
                                    $keyword    = htmlentities($_GET["keyword"]);
                                    echo '<div id="post"> <div id="rheading">searched for '.$keyword.'</div> </div>';
                                }
                                
                                $id     =   htmlentities($_GET["id"]);
                                $jres   =   $ifunc->getSearchResult($id);
                                $LESS   =   new less();
                                $jres   =   $LESS->removeUncompleteHtml($jres);
                                //var_dump($jres);
                                echo $jres;
                            }
                            else{
                                echo '<div class="bcseter">what can we help you</div>';
                            }
                        ?>
                        
                        <div id="post"> <div id="rheading">post new comment</div> </div>
                        <div id="p-post">
                            <div id="post-heading">
                                <div id="post-ppic" style="background:url(upics/<?php echo $_SESSION["tls_upic"]; ?>);"></div> 
                                <a href="profile.php?uid=<?php echo $_SESSION["tls_uid"]; ?>" id="md-lnk"><?php echo $_SESSION["tls_uname"]; ?></a>
                                <div id="oti"><?php echo date("M d, Y");?></div>
                            </div>
                            
                            <!-- user comment-->
                            <div class="uinarea">
                                <form action="saver.php?job=comment&&oid=<?php echo $id; ?>" method="post" enctype="multipart/form-data">
                                    <div id="ndatarow">
                                        <textarea id="fuin" name="upost" placeholder="share your comment"></textarea>
                                        <input type="hidden" class="attachments-status" name="attachments-status" value="hamna"/>
                                    </div>
                                    <div id="attachments">

                                    </div>
                                    <div class="rseter">
                                        <div id="attach">
                                            <div id="attachIco"><img src="icons/attachment.png"/></div>
                                            <input type="file" id="attachIn" name="attachments[]" multiple="multiple"/>
                                            <div id="attachTitle">Attachments</div>
                                        </div>
                                        <button id="submit">post</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                        
                        <div id="post"> <div id="rheading">comments (<?php echo $ifunc->getPostStatsNums("comments",$id); ?>)</div> </div>
                        <?php echo $ifunc->getPostComments($id); ?>
                    </div>
                </div>
                <?php include 'right-cards.php'; ?>
            </div>
        <?php else:?>
            <script type="text/javascript">
                $(document).ready(function(){
                    window.location.href    =   "index.php";
                });
            </script>
        <?php endif;?>
    </body>
</html>