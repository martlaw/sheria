<div id="rightCards">
    
    <a class="btlink lwi" href="">
        <div id="lwi-icon"><img src="icons/book.png"/></div>
        <div id="lwi-title">Constitution</div>
    </a>
    
    <div id="sideCard">
        <div id="profileCover">
            <div id="profilePic" style="background:url(upics/<?php echo $_SESSION["tls_upic"]; ?>);"></div>
            <div id="profileName"> <?php echo $_SESSION["tls_uname"]; ?></div>
        </div>
        <a href="profile.php?uid=<?php echo $_SESSION["tls_uid"]?>" class="btlink cppic">profile</a>
    </div>

    <?php
        if($_SESSION["tls_usstatus"]=="false"){
            echo '<a href="mesePay.php" class="btlink uptp">upgrade to premium</a>'; 
        }
        else{
            echo '';
        }
    ?>
    
    <div id="sideCard">
        <div id="cardDarkBl">
            categories
        </div>
        <div class="categories">
            <?php
                # get categories
                echo $ifunc->getCategories($mysqliAR[1],"side");
                # end get categories
            ?>
        </div>
        
        
    </div>
</div>