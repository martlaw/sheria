<?php

    class ifunc{
        private $uid,$userData,$ulevel;
        private $mysqli,$dataSql,$dataQuery,$dataRows,$dataFetch,
                $dtSql,$dtQuery,$dtRows,$dtFetch,
                $dt1Sql,$dt1Query,$dt1Rows,$dt1Fetch,
                $dt2Sql,$dt2Query,$dt2Rows,$dt2Fetch,
                $dt3Sql,$dt3Query,$dt3Rows,$dt3Fetch,
                $dt4Sql,$dt4Query,$dt4Rows,$dt4Fetch,
                $dt5Sql,$dt5Query,$dt5Rows,$dt5Fetch,
                $dt6Sql,$dt6Query,$dt6Rows,$dt6Fetch;
        
        private $postData,$tmpData,$dataTRA,$dataTESC,$funcDataTR,$htmlTR,$html2TR,$html3TR;
        public  $dataTRAER;
        
        private $upass;
        public  $cnames,$ccodes;
        public  $formDatas,$formDataV;
        
        
        #time
        private $tddate,$tdtime,$tdyear;
        
        #search keyword
        private $searchKeyword;
        
        # DBA
        private $DBAtable,$DBAcond,$DBAdataAR,$DBAdataJSON,$DBAdataTR,$DBAdataHTML;
        
        function __construct($mysqli) {
            $this->mysqli       =   $mysqli;
            $this->uid          =   $_SESSION["tls_uid"];
            $this->dataTRAER    =   0;
            $this->dataTESC     =   "'~!*,`\":";
            $this->tddate       =   date("M d, Y");
            $this->tdtime       =   date("H:i");
            $this->tdyear       =   date("Y");
            
        }
        
        function getPostVals(){
            $this->dataTRA  =   array();
            foreach($_POST as $val){
                $this->tmpData          =   addcslashes(htmlentities(trim($val)), $this->dataTESC);
                
                if(strlen($this->tmpData)>0){
                    $this->dataTRA[]    =   $this->tmpData;
                }
                else{
                    $this->dataTRA[]    =   "none";
                    $this->dataTRAER    +=1;
                }
            }
            
            return $this->dataTRA;
        }
        
        # user by pass
        function getUserByPass($ucontact,$upass){
            $this->upass        =   strrev(md5(strrev($upass)));
            $this->dataSql      =   "SELECT * FROM sys_users WHERE uemail='$ucontact' AND upass='$this->upass' OR uphone='$ucontact' AND upass='$this->upass' LIMIT 1";
            $this->dataQuery    =   $this->mysqli->query($this->dataSql);
            $this->dataRows     =   $this->dataQuery->num_rows;
            if($this->dataRows==1){
                while($this->dataFetch= $this->dataQuery->fetch_assoc()){
                    $this->funcDataTR   =   $this->dataFetch;   
                }
            }
            else {  $this->funcDataTR   =   "none";}
           
            return $this->funcDataTR;
        }
        
        # user by email
        function getUserByEmail($uemail){
            $this->dataSql      =   "SELECT * FROM sys_users WHERE uemail='$uemail' LIMIT 1";
            $this->dataQuery    =   $this->mysqli->query($this->dataSql);
            $this->dataRows     =   $this->dataQuery->num_rows;
            if($this->dataRows==1){
                while($this->dataFetch= $this->dataQuery->fetch_assoc()){
                    $this->funcDataTR   =   $this->dataFetch;   
                }
            }
            else {  $this->funcDataTR   =   "none";}
            
            return $this->funcDataTR;
        }
        
        # user by id
        function getUserByID($id){
            $this->dataSql      =   "SELECT * FROM sys_users WHERE id='$id' LIMIT 1";
            $this->dataQuery    =   $this->mysqli->query($this->dataSql);
            $this->dataRows     =   $this->dataQuery->num_rows;
            if($this->dataRows==1){
                while($this->dataFetch= $this->dataQuery->fetch_assoc()){
                    $this->funcDataTR   =   $this->dataFetch;   
                }
            }
            else {  $this->funcDataTR   =   "none";}
            
            return $this->funcDataTR;
        }
        
        function getMostVisited(){
            $this->dt3Sql   =   "SELECT pid FROM pviews GROUP BY pid LIMIT 5";
            $this->dt3Query = $this->mysqli->query($this->dt3Sql);
            $this->dt3Rows  = $this->dt3Query->num_rows;
            
            
            if($this->dt3Rows>0){
                $this->htmlTR   =   '';
                while($this->dt3Fetch= $this->dt3Query->fetch_assoc()){
                    
                    $this->postData =   $this->getPostDataByID("post",$this->dt3Fetch["pid"]);
                    if($this->postData=="none"){
                        $this->htmlTR   =   '<div class="bcseter"> no data found </div>';
                    }else{
                        $this->addResultHtml($this->postData[0]);
                    }
                }
            }
            
            return $this->htmlTR;
        }
        
        # search data by keyword
        function searchData($keyword){
            $this->dt4Sql   =   "SELECT * FROM judgements WHERE jcategory='$keyword' OR jtitle='$keyword' OR jtitle LIKE '$keyword%' OR jtitle LIKE '%$keyword%' OR jsnippet='$keyword' OR jsnippet LIKE '$keyword%' OR jsnippet LIKE '%$keyword%' OR jcontent='$keyword' OR jcontent LIKE '$keyword%' OR jcontent LIKE '%$keyword%'";
            $this->dt4Query =   $this->mysqli->query($this->dt4Sql);
            $this->dt4Rows  =   $this->dt4Query->num_rows;
            $this->htmlTR   =   '';
            if($this->dt4Rows>0){
                while($this->dt4Fetch= $this->dt4Query->fetch_assoc()){
                    $this->searchKeyword    =   $keyword;
                    $this->addResultHtml($this->dt4Fetch);
                }
            }
            else{
                $this->htmlTR   =   '<div class="bcseter"> no data found </div>';
            }
            
            return $this->htmlTR;
        }
        
        function addResultHtml($dtAR){
            $this->htmlTR   .=  '<div id="post">
                                    <div id="post-heading"><a href="result.php?result=true&&id='.$dtAR["pid"].'&&keyword='.urlencode($this->searchKeyword).'" id="lnk">'.$dtAR["jtitle"].'</a></div>
                                    <div id="post-content">'.$dtAR["jsnippet"].'</div>
                                    '.$this->getPostStatistics($dtAR["pid"]).'
                                </div>';
        }
        
        # get post array by id
        function getPostDataByID($typ,$id){
            if($typ=="post"){           $this->dt4Sql   =   "SELECT * FROM judgements WHERE pid='$id' LIMIT 1"; }
            else if($typ=="comments"){  $this->dt4Sql   =   "SELECT * FROM ucomments WHERE pid='$id'";  }
            
            $this->dt4Query =   $this->mysqli->query($this->dt4Sql);
            $this->dt4Rows  =   $this->dt4Query->num_rows;
            if($this->dt4Rows==1){
                $this->dataTRA  =   array();
                while($this->dt4Fetch= $this->dt4Query->fetch_assoc()){
                    $this->dataTRA[]    =   $this->dt4Fetch;
                }
                
                return $this->dataTRA;
            }
            else{
                return "none";
            }
        }
        
        # get search result
        function getSearchResult($id){
            $this->postData =   $this->getPostDataByID("post",$id);
            $this->htmlTR   =   '';
            
            if($this->postData=="none"){
                $this->htmlTR   =   '<div class="bcseter"> no data found </div>';
            }
            else{
                $this->htmlTR   =   '<div id="paper-view">';
                    if($_SESSION["tls_usstatus"]=="true"){
                        $this->htmlTR   .=   $this->postData[0]["jcontent"];
                    }else{
                        $this->htmlTR   .=   substr($this->postData[0]["jcontent"],0,500);
                    }
                                    
                $this->htmlTR   .=  $this->getPostStatistics($this->postData[0]["pid"]);
                $this->htmlTR   .=  '</div>';
                    
                #update views
                $this->updateViews($this->postData[0]["pid"]);
            }
            
            return $this->htmlTR;
        }
        
        
        # update post views
        function updateViews($id){
            $this->dt1Sql   =   "SELECT * FROM pviews WHERE uid='$this->uid' AND pid='$id'";
            $this->dt1Query =   $this->mysqli->query($this->dt1Sql);
            $this->dt1Rows  =   $this->dt1Query->num_rows;
            if($this->dt1Rows==1){
                $this->dt2Sql  =   "UPDATE pviews SET vdate='$this->tddate' WHERE uid='$this->uid' AND pid='$id'";
                $this->mysqli->query($this->dt2Sql);
            }
            else{
                $this->dt2Sql  =   "INSERT INTO pviews(uid,pid,vdate) VALUES('$this->uid','$id','$this->tddate')";
                $this->mysqli->query($this->dt2Sql);
            }
        }
        
        # get post statistics
        function getPostStatistics($id){
            return '    <div id="post-statistics">
                            <div id="post-sts-icon"><img src="icons/views.png"/></div>
                            <div id="post-sts-info">'.$this->getPostStatsNums("views",$id).'</div>
                            <div id="post-sts-icon"><img src="icons/comment.png"/></div>
                            <div id="post-sts-info">'.$this->getPostStatsNums("comments",$id).'</div>
                        </div>';
        }
        
        # get posts statistics
        function getPostStatsNums($tb,$id){
            switch($tb){
                case "views":       $this->dt6Sql   =   "SELECT * FROM pviews WHERE uid='$this->uid' AND pid='$id'";    break;
                case "comments":    $this->dt6Sql   =   "SELECT * FROM ucomments WHERE uid='$this->uid' AND pid='$id'"; break; 
                default :           $this->dt6Sql   =   "SELECT * FROM ucomments WHERE uid='$this->uid' AND pid='$id'"; break; 
            }
            
            $this->dt6Query =   $this->mysqli->query($this->dt6Sql);
            $this->dt6Rows  =   $this->dt6Query->num_rows;
            
            return $this->dt6Rows;
            
        }
        
        # get post comments
        function getPostComments($id){
            
            $this->postData =   $this->getPostDataByID("comments", $id);
            
            $this->html2TR   =   '';
            if($this->postData!="none"){
                for($i=0;$i<count($this->postData);$i++){
                    $this->userData     =   $this->getUserByID($this->postData[$i]["uid"]);
                    
                    $this->html2TR      =   '<div id="p-post">
                                                <div id="post-heading">
                                                    <div id="post-ppic" style="background:url(upics/'.$this->userData["upic"].');"></div> 
                                                    <a href="profile.php?uid='.$this->userData["id"].'" id="md-lnk">'.$this->userData["uname"].'</a>
                                                    <div id="oti">'.$this->postData[$i]["cdate"].'</div>
                                                </div>
                                                <div id="post-content">'.$this->postData[$i]["ucomment"].'</div>
                                            </div>';
                }
            }
            
            return $this->html2TR;
        }
        
        # get categories
        function getCategories($mysqli,$typ){
            
            $this->DBAtable     =   "web_data";
            $this->DBAcond      =   " WHERE dtype='category'";
            $this->DBA          =   new dba($mysqli, $this->DBAtable, $this->DBAcond);
            $this->DBA->getData();
            $this->DBAdataAR    =   $this->DBA->dataTRA;
            
            $this->html3TR      =   "";
            if(count($this->DBAdataAR)>0){
                
                if(count($this->DBAdataAR)>5&&($typ=="top")){
                    for($c=0;$c<5;$c++){
                        $this->html3TR .=   '<a href="index.php?results=true&&keyword='.urlencode($this->DBAdataAR[$c]['udata1']).'" class="btlink top-category"> <img id="top-category-icon" src="icons/cat.png"/> <i id="top-category-title"> '.$this->DBAdataAR[$c]['udata1'].' </i> </a>';
                    }
                    
                    $this->html3TR .=   '<select id="more-cases-categories">';
                    $this->html3TR .=   '<option>more categories</option>';
                    for($c=5;$c<count($this->DBAdataAR);$c++){
                        $this->html3TR .=   '<option value="'.$this->DBAdataAR[$c]['udata1'].'"> '.$this->DBAdataAR[$c]['udata1'].' </option>';
                    }
                    $this->html3TR .=   '</select>';
                    
                    
                }
                else{
                    for($c=0;$c<count($this->DBAdataAR);$c++){
                        if($typ=="side"){
                            $this->html3TR .=   '<a href="index.php?results=true&&keyword='.urlencode($this->DBAdataAR[$c]['udata1']).'" class="btlink category"> <img id="category-icon" src="icons/cat.png"/> <i id="category-title"> '.$this->DBAdataAR[$c]['udata1'].' </i> </a>';
                        }
                        else if($typ=="top"){
                            $this->html3TR .=   '<a href="index.php?results=true&&keyword='.urlencode($this->DBAdataAR[$c]['udata1']).'" class="btlink top-category"> <img id="top-category-icon" src="icons/cat.png"/> <i id="top-category-title"> '.$this->DBAdataAR[$c]['udata1'].' </i> </a>';
                        }
                    }
                }
                    
            }else{  echo '<div class="bcseter">no categories</div>';}
            
            if($typ=='top'){
                $this->html3TR = '<div class="top-categories"> <div id="rheading">categories</div> '.$this->html3TR.'</div>';
            }
            
            return $this->html3TR;
        }
        
        # upgrade user from 
        function upgradeUser($dys){
            $this->dt5Sql   =   "UPDATE sys_users SET usstatus='true',uson='". time()."',usdays='$dys' WHERE id='$this->uid'";
            $this->dt5Query =   $this->mysqli->query($this->dt5Sql);
            if($this->dt5Query){ return "done"; }
            else{     return "not-done"; }
        }
        
        # get posts
        function getPosts($cond){
            $this->DBAtable     =   "posts";
            $this->DBAcond      =   $cond;
            $this->DBA          =   new dba($this->mysqli, $this->DBAtable, $this->DBAcond);
            $this->DBA->getData();
            
            if($this->DBA->dataECode==0){
                
                # posts data
                $this->dbaData  =   $this->DBA->dataTRA;
                
                for($p=0;$p<count($this->dbaData);$p++){
                    # get user data
                    $this->userData     =   $this->getUserByID($this->dbaData[$p]["uid"]);
                    
                    # display post
                    $this->DBAdataHTML  .=  '<div id="p-post">
                                                <div id="post-heading">
                                                    <div id="post-ppic" style="background:url(upics/'.$this->userData["upic"].');"></div> 
                                                    <a href="profile.php?uid='.$this->userData["id"].'" id="md-lnk">'.$this->userData["uname"].'</a>
                                                    <div id="oti">'.$this->dbaData[$p]["pdate"].'</div>
                                                </div>
                                                <div id="post-content">'.$this->dbaData[$p]["post"].'</div>
                                            </div>';
                }
            }
            else{ $this->DBAdataHTML  =   '<div class="bcseter"> no post(s) found </div>'; }
            
            return $this->DBAdataHTML;
        }
        
        # get requests
        function getRequests($cond){
            $this->DBAtable     =   "requests";
            $this->DBAcond      =   $cond;
            $this->DBA          =   new dba($this->mysqli, $this->DBAtable, $this->DBAcond);
            $this->DBA->getData();
            
            if($this->DBA->dataECode==0){
                
                # posts data
                $this->dbaData  =   $this->DBA->dataTRA;
                
                for($p=0;$p<count($this->dbaData);$p++){
                    # get user data
                    $this->userData     =   $this->getUserByID($this->dbaData[$p]["uid"]);
                    
                    # display post
                    $this->DBAdataHTML  .=  '<div id="p-post">
                                                <div id="post-heading">
                                                    <div id="post-ppic" style="background:url(upics/def.jpg);"></div> 
                                                    <a href="profile.php?uid='.$this->userData["id"].'" id="md-lnk">'.$this->userData["uname"].'</a>
                                                    <div id="oti">'.$this->dbaData[$p]["rdate"].'</div>
                                                </div>
                                                <div id="post-content">
                                                    <div id="rheading">'.$this->dbaData[$p]["title"].'</div>
                                                    '.$this->dbaData[$p]["content"].'
                                                </div>
                                            </div>';
                }
            }
            else{ $this->DBAdataHTML  =   '<div class="bcseter"> no request(s) found </div>'; }
            
            return $this->DBAdataHTML;
        }
        
        # get profile
        function getUserProfile($id){
            $this->puserData    =   $this->getUserByID($id);
            $this->html4TR      =   "";
            if($this->puserData!="none"){
                $this->html4TR  .=  '<div class="profile">
                                        <div id="profile-cover">
                                            <title>'.$this->puserData["uname"].' | Profile</title>
                                            <div class="inline profile-pic" style="background:url(upics/'.$this->puserData["upic"].');"></div>
                                            <div id="profile-name">'.$this->puserData["uname"].'</div>
                                            <div id="profile-contacts">
                                                <div class="inline profile-contact">
                                                    <img class="inline profile-contact-icon" src="icons/contacts.png"/>
                                                    <div class="inline profile-contact-info">'.$this->puserData["uphone"].'</div>
                                                </div>
                                                <div class="inline profile-contact">
                                                    <img class="inline profile-contact-icon" src="icons/email-white.png"/>
                                                    <div class="inline profile-contact-info">'.$this->puserData["uemail"].'</div>
                                                </div>
                                                <div class="inline profile-contact">
                                                    <img class="inline profile-contact-icon" src="icons/map-pin-white.png"/>
                                                    <div class="inline profile-contact-info"> Dar es salaam</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="profile-top-categories">
                                        <a href="index.php?results=true&amp;&amp;keyword=civil" class="btlink profile-top-category"> 
                                            <img id="top-category-icon" src="icons/cat.png"> 
                                            <i id="top-category-title"> Add Template </i>
                                        </a>

                                        <a href="user.php?action=change-pic" class="btlink profile-top-category"> 
                                            <img id="top-category-icon" src="icons/cat.png"> 
                                            <i id="top-category-title"> Edit profile picture </i>
                                        </a>
                                    </div>';
            }
            else{ $this->html4TR    .=  '<div class="bcseter">user not found</div>'; }
            
            return $this->html4TR;
        }
    }
?>