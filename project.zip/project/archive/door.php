<?php
    session_start();
    include 'dbconnect.php';
    include 'ifunc.php';
    
    class door{
        private $uid,$udata,$ulevel,$ifunc;
        private $mysqli,$dataSql,$dataQuery,$dataRows,$dataFetch,
                $dtSql,$dtQuery,$dtRows,$dtFetch,
                $dt2Sql,$dt2Query,$dt2Rows,$dt2Fetch,
                $sdata,$sdata1,$sdata2;
        
        private $pdataAR,$pdataARER,$dataTESC;
        private $upass;
        private $job,$goTO;
        
        
        function __construct($mysqli) {
            $this->mysqli       =   $mysqli;
            $this->dataTESC     =   "'~!*`\":";
            $this->job          =   htmlentities(trim($_GET["job"]));
            $this->ifunc        =   new ifunc($this->mysqli);
            $this->pdataAR      =   $this->ifunc->getPostVals();
            $this->pdataARER    =   $this->ifunc->dataTRAER;
            
            //print_r($this->pdataAR);
            
            if($this->job=="logout"){
                $this->closeDoor();
            }
            else{
                if($this->pdataARER==0){
                    switch($this->job){
                        case "login":       $this->openDoor();      break;
                        case "register":    $this->createUser();    break;
                    }
                }
                else{   $this->goTO =   "user.php?action=".$this->job."&&error=1&&msg=".urlencode("Please Fill all fields"); }
            }
        }
        
        function openDoor(){
            $this->udata    =   $this->ifunc->getUserByPass($this->pdataAR[0],$this->pdataAR[1]);
            if($this->udata!="none"){
                $_SESSION["tls_login"]     =   true;
                $_SESSION["tls_uid"]       =   $this->udata["id"];
                $_SESSION["tls_upic"]      =   $this->udata["upic"];
                $_SESSION["tls_uemail"]    =   $this->udata["uemail"];
                $_SESSION["tls_uphone"]    =   $this->udata["uphone"];
                $_SESSION["tls_uname"]     =   $this->udata["uname"];
                $_SESSION["tls_usstatus"]  =   $this->udata["usstatus"];
                $_SESSION["tls_uson"]      =   $this->udata["uson"];
                $_SESSION["tls_utype"]     =   $this->udata["utype"];
                
                        $this->goTO =   "index.php?done=1&&msg=".urlencode("Welcome, you have successful logged in");
            }
            else{       $this->goTO =   "user.php?action=".$this->job."&&error=1&&msg=".urlencode("Wrong username or password");}
        }
        
        function createUser(){
            $this->udata    =   $this->ifunc->getUserByEmail($this->pdataAR[1]);
            if($this->udata=="none"){
                if($this->pdataAR[3]==$this->pdataAR[4]){
                    $this->upass    =   strrev(md5(strrev($this->pdataAR[3])));
                    $this->sdata    =   "'".$this->pdataAR[0]."','".$this->pdataAR[1]."','".$this->pdataAR[2]."','".$this->upass."'";
                    $this->dtSql    =   "INSERT INTO sys_users (uname,uemail,uphone,upass) VALUES(".$this->sdata.")";
                    
                    if($this->dtQuery  = $this->mysqli->query($this->dtSql)){
                        $_SESSION["tls_login"]     =   true;
                        $_SESSION["tls_uid"]       =   $this->mysqli->insert_id;
                        $_SESSION["tls_upic"]      =   "def.png";
                        $_SESSION["tls_uemail"]    =   $this->pdataAR[1];
                        $_SESSION["tls_uphone"]    =   $this->pdataAR[2];
                        $_SESSION["tls_uname"]     =   $this->pdataAR[0];
                        $_SESSION["tls_usstatus"]  =   "false";
                        $_SESSION["tls_uson"]      =   "none";
                        $_SESSION["tls_utype"]     =   "normal";
                
                        $this->goTO =   "index.php?done=1&&msg=".urlencode("Welcome, you have successful logged in");
                    }
                    else{
                        $this->goTO =   "user.php?action=".$this->job."&&error=1&&msg=".urlencode("Failed to Register user");
                    }
                }
                else{   $this->goTO =   "user.php?action=".$this->job."&&error=1&&msg=".urlencode("Passwords do not match");        }
            }
            else{       $this->goTO =   "user.php?action=".$this->job."&&error=1&&msg=".urlencode("Email Address Already in Use");  }
        }
        
        function closeDoor(){
            $_SESSION["tls_login"]     =   false;
            session_destroy();
            $this->goTO =   "index.php?done=1&&msg=".urlencode("you have successful logged out");
        }
        
        function output(){
            header("Location: $this->goTO");
        }
    }
    
    $door   =   new door($mysqli);
    $door->output();
?>