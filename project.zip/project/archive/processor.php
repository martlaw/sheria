<?php
    session_start();
    #an edumek system
    #make changes as instructed 
    #powered by MESE AI
    #mese@edumek.com
    #www.edumek.com
    
    include 'dbconnect.php';
    include 'ifunc.php';

    $tpesa      =   "0711341115";                                                           # tigopesa number
    $mpesa      =   "none";                                                                 # vodacom mpesa number
    $voucher    =   "none";                                                                 # voucher entered by a user
    if(isset($_POST["voucher"])){ $voucher    =   trim(htmlentities($_POST["voucher"])); }  # voucher entered by a user - REAL
    

    #verify voucher
    $meseReqUrl     =   "http://mese.edumek.com/meseai.php";                                                   # MESEAI url
    $meseReqPars    =   "tpesa=".$tpesa."&&mpesa=".$mpesa."&&voucher=".$voucher."&&job=mpay&&do=req";       # voucher verification params
    $meseUpdPars    =   "tpesa=".$tpesa."&&mpesa=".$mpesa."&&voucher=".$voucher."&&job=mpay&&do=upd";       # voucher updation params
    $mese           =   curl_init();
                        curl_setopt($mese, CURLOPT_URL,$meseReqUrl);
                        curl_setopt($mese, CURLOPT_POST,1);
                        curl_setopt($mese, CURLOPT_POSTFIELDS,$meseReqPars);
                        curl_setopt($mese, CURLOPT_RETURNTRANSFER, true);

    $meseOutput     =   curl_exec ($mese);
                        curl_close ($mese);
    $meseOutput     =   json_decode($meseOutput);
    $meseStatus     =   $meseOutput->status;
    $meseMsg        =   $meseOutput->msg;
    $meseAmount     =   $meseOutput->amount;

    if(isset($_POST["voucher"])){
                        if($meseStatus=="done"){
                            # handle success 
                            $tlsPremiumDays =   0;
                            if($meseAmount==95000){
                                $tlsPremiumDays = 365;   
                            }
                            else{
                                $tlsPremiumDays =   round($meseAmount/300,0); ;  
                            }
                                
                            
                            $ifunc  =   new ifunc($mysqli);
                            $ifunc->upgradeUser($tlsPremiumDays);

                            $goTO           =   "index.php?done=1&&msg=".urlencode($alertMsg);
                                
                            # end handle success
                            # update voucher
                                
                            $mese           =   curl_init();
                                                curl_setopt($mese, CURLOPT_URL,$meseReqUrl);
                                                curl_setopt($mese, CURLOPT_POST,1);
                                                curl_setopt($mese, CURLOPT_POSTFIELDS,$meseUpdPars);
                                                curl_setopt($mese, CURLOPT_RETURNTRANSFER, true);

                            $meseOutput     =   curl_exec ($mese);
                                                curl_close ($mese);
                            $meseOutput     =   json_decode($meseOutput);
                            $meseStatus     =   $meseOutput->status;
                            $meseMsg        =   $meseOutput->msg;
                        }
                        else{
                            // error handling code
                            $goTO           =   "mesePay.php?error=1&&msg=".urlencode($meseMsg);
                        }
    }
    else{   $goTO           =   "mesePay.php?error=1&&msg=".urlencode("Please insert voucher code"); }   
    
    header("Location: $goTO");
    
?>