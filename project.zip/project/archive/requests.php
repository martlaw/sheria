<?php session_start(); ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title>Requests</title>
        <?php include'head.php'; ?>
    </head>
    <body>
        <?php include 'nav.php'; ?>
        <?php if((isset($_SESSION["tls_login"]))&&($_SESSION["tls_login"]==true)):?>
            <div class="cards">
                <?php 
                
                    include 'nav.php';
                    include 'less/dba.php';
                    include 'dbconnect.php';
                    include 'ifunc.php';
                    $ifunc          =   new ifunc($mysqli);
                    
                    
                    
                ?>
                
                
                <div id="b-leftCards">
                    
                    <div class="posts">
                        <div id="rheading">user requests</div>
                        <?php
                            # get profile posts
                            $postsCond  =   "ORDER BY rid DESC";
                            echo $ifunc->getRequests($postsCond);
                        ?>
                    </div>
                </div>

                <?php include 'right-cards.php'; ?>
            </div>
        <?php else:?>
        
        <?php endif;?>
    </body>
</html>