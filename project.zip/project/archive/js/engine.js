$(document).ready(function(){
    var attachmentButton    =   $(".uinarea input#attachIn");
    var attachmentsArea     =   $(".uinarea div#attachments");
    var inlineSearchIN      =   $(".searchAR input#consin");
    var inlineSearchBT      =   $(".searchAR button#conssub");
    
    // triggers
    var categorySelect      =   $(".cards select#more-cases-categories");
    
    
    
        attachmentButton.change(function(){
            
            if(this.files){
                var filesNum    =   this.files.length;
                    for(var i=0;i<filesNum;i++){
                        var areader     =   new FileReader();
                        areader.onload  =   function(e){
                            attachmentsArea.append('<div id="attachment" style="background:url('+e.target.result+');"></div>');
                        };
                        areader.readAsDataURL(this.files[i]); 
                    }
            }
        });
        
        
        //*** TRIGGERS FUNCTIONS *//
        // search submit
        inlineSearchBT.click(function(){
            var keyword =   inlineSearchIN.val().trim();
                if(keyword.length>0){
                    window.location.href    =   "index.php?results=true&&keyword="+encodeURIComponent(keyword);
                }else{
                    inlineSearchIN.focus().css("background","#fffabf");
                }
        });
        
        // category select change
        categorySelect.change(function(){
            var keyword =   $(this).val();
                window.location.href    =   "index.php?results=true&&keyword="+encodeURIComponent(keyword);
        });
});