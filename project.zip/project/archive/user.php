<?php session_start(); ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <?php include'head.php'; ?>
    </head>
    <body>
        <?php include 'nav.php'; ?>
        <?php
            $action     =   "none";
            if(isset($_GET["action"])){
                $action =   htmlentities(trim($_GET["action"]));   
            }
        ?>
        <div class="cards">
            <?php if((isset($_SESSION["tls_login"]))&&($_SESSION["tls_login"]==true)):?>
                <!-- login user action -->
                <div id="centerCards">
                    <?php if($action=="change-pic"):?>
                        <title>Legal Bank | Change profile picture</title>
                        <div id="formCard">
                            <form action="saver.php?job=change-pic" method="POST" enctype="multipart/form-data">
                                <div class="uinarea">
                                    <h2 id="cformTitle"></h2>

                                    <!-- Profile picture-->
                                    <div id="ppic-changer">
                                        <div id="ppic-area">
                                            <img id="ap-pic-img" src="upics/<?php echo $_SESSION["tls_upic"]; ?>"/>
                                        </div>
                                        <div id="ppic-sel">
                                            <input type="file" id="file-in" name="ppic" data-job="ppic"/>
                                            Select Image
                                        </div>
                                    </div>
                                    <div id="ndatarow"> <button id="submit" type="submit">save</button> </div>
                                </div>
                            </form>
                        </div>
                    <?php else:?>

                    <?php endif;?>
                </div>
            <?php else:?>
                <!-- not login user -->
                <?php if(($action=="login")||($action=="register")):?>
                    <div id="lr-card">
                        <form action="door.php?job=<?php echo $action; ?>" method="POST">
                            <div id="lr-card-con">
                                <?php if($action=="login"): ?>
                                    <title>Legal Bank | Login</title>
                                    <h2 id="cformTitle">Login</h2>
                                    <input type="text" id="lr-fuin" name="email"   placeholder="Email or phone"/>
                                    <input type="password" id="lr-fuin" name="pass"    placeholder="password"/>
                                    <div id="cseter">
                                        <button id="lr" type="submit"> Login </button>
                                    </div>
                                <?php else: ?>
                                    <title>Legal Bank | Register</title>
                                    <h2 id="cformTitle">Register</h2>
                                    <input type="text" id="lr-fuin" name="name"   placeholder="Full name"/>
                                    <input type="text" id="lr-fuin" name="email"   placeholder="Email"/>
                                    <input type="text" id="lr-fuin" name="phone"   placeholder="Phone"/>
                                    <input type="password" id="lr-fuin" name="pass1"    placeholder="password"/>
                                    <input type="password" id="lr-fuin" name="pass2"    placeholder="Confirm password"/>
                                    <div id="cseter">
                                        <button id="lr" type="submit"> Register </button>
                                    </div>
                                <?php endif;?>
                                <?php
                                    if(isset($_GET["error"]) && isset($_GET["msg"]) ){
                                        if($_GET["error"]=="done"){
                                            echo '<div id="cardDone">'.$_GET["msg"].'</div>';
                                        }
                                        else{
                                            echo '<div id="cardError">'.$_GET["msg"].'</div>';
                                        }
                                    }
                                ?>
                            </div>
                        </form>

                    </div>
                <?php else:?>

                <?php endif;?>
            <?php endif;?>
        </div>
    </body>
</html>