<?php session_start(); ?>
<!DOCTYPE html>
<html>
    <head>
        <title>MESE Payment</title>
        <meta charset="utf-8"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
        <link href="http://mese.edumek.com/css/mpay.css" rel="stylesheet"/>
    </head>
    <body>
        <?php
            if(isset($_GET['profuct'])){
                $_SESSION['mese_product_tp']    =   htmlentities($_GET['profuct']);
            }
        ?>
        <div class="header">
            <div id="nav">
                <a href="index.php" class="btlike home">home </a>
            </div>
        </div>
        <div class="parea">
            <div id="pcon">
                <div id="logoAR"> <div id="logo"><img src="http://mese.edumek.com/icons/mpay.png"/></div> </div>
                <div id="methods"> <img src="http://mese.edumek.com/icons/methods.png"/> </div>
                <div id="inst">
                    For tiGO pesa send required amount to 0711341115 by dialing *150*01#<br>
                    You will receive voucher code starting with MP<br>
                </div>
                <div id="inst-b"> NOTE: 1 year subscription = 95,000 Tsh | 1 day = 300 Tsh  </div>
                <div id="footer">
                    <form action="processor.php" method="post">
                        <input id="voucher" type="text" name="voucher" placeholder="Enter voucher code e.g MPXXXXXXXXXX"/>
                        <button id="confirm" type="submit">confirm</button>
                    </form>
                </div>
            </div>
            <?php
                if(isset($_GET["done"])&&isset($_GET["msg"])){
                    echo '<div id="doneAR">'.$_GET["msg"].'</div>';
                }
                else if(isset($_GET["error"])&&isset($_GET["msg"])){
                    echo '<div id="errorAR">'.$_GET["msg"].'</div>';
                }
            ?>
            <div id="rights"> powered by MESE AI | customer care - sms HELP to 0711341115</div>
        </div>
    </body>
</html>