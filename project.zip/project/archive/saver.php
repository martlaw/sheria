<?php
    session_start();
    date_default_timezone_set("Africa/Dar_es_Salaam");
    
    include 'dbconnect.php';
    include 'ifunc.php';
    include 'sdata.php';
    
    
    class saver{
        private $uid,$oid,$udata,$ulevel,$ifunc;
        private $mysqli,$dataSql,$dataQuery,$dataRows,$dataFetch,$dataQueryStatus,
                $dtSql,$dtQuery,$dtRows,$dtFetch,$dtQueryStatus,
                $dt1Sql,$dt1Query,$dt1Rows,$dt1Fetch,
                $dt2Sql,$dt2Query,$dt2Rows,$dt2Fetch,
                $dt3Sql,$dt3Query,$dt3Rows,$dt3Fetch,
                $dt4Sql,$dt4Query,$dt4Rows,$dt4Fetch,
                $dt5Sql,$dt5Query,$dt5Rows,$dt5Fetch,
                $dt6Sql,$dt6Query,$dt6Rows,$dt6Fetch,
                $sdata,$sdataV1,$sdataV2,$sdataV3,$sdataVAR;
        
        private $pdataAR,$pdataARER,$dataTESC;
        private $job,$stage,$goTO,$goTOpage;
        
        #post and comments
        private $postType;
        
        #pics upload
        private $allFname,$fName,$fNewName,$ftmpName,$fLocation,$fExtension,$attachmentsER,$attachmentsERmsg;
        
        #time
        private $tddate,$tdtime,$tdyear;
        
        function __construct($mysqli) {
            $this->mysqli       =   $mysqli;
            $this->uid          =   $_SESSION["tls_uid"];
            
            $this->oid          =   "none";
            if(isset($_GET["oid"])){    $this->oid  =   htmlentities($_GET["oid"]); }
            
            $this->dataTESC     =   "'~!*,`\":";
            $this->job          =   htmlentities(trim($_GET["job"]));
            $this->ifunc        =   new ifunc($this->mysqli);
            $this->pdataAR      =   $this->ifunc->getPostVals();
            $this->pdataARER    =   $this->ifunc->dataTRAER;
            
            #time and dates
            $this->tddate       =   date("M d, Y");
            $this->tdtime       =   date("H:i");
            $this->tdyear       =   date("Y");
            
            # redirect
            $this->postType     =   $this->job;
            switch ($this->job){
                case "status":  $this->goTOpage   =   "index.php";  break;
                case "comment": $this->goTOpage   =   "result.php"; break;
            }
            
            if($this->job=="change-pic"){
                $this->saveProfilePic();
            }
            else{
                if($this->pdataARER==0){
                    switch($this->job){
                        case "status":      $this->postStatus();        break;
                        case "comment":     $this->postStatus();       break;
                    }
                }
            }
        }
        
        function postStatus(){
            $this->allFname         =   "none";
            $this->attachmentsER    =   0;
            
            if(isset($_FILES["attachments"]["tmp_name"])&&(count($_FILES["attachments"]["tmp_name"])>0) &&(strlen($_FILES["attachments"]["name"][0])>0)){
                foreach($_FILES["attachments"]["tmp_name"] as $key => $val){
                    $this->fName        =   $_FILES["attachments"]["name"][$key];
                    $this->ftmpName     =   $_FILES["attachments"]["tmp_name"][$key];

                    $this->fExtension   =   strtolower(substr($this->fName, strrpos($this->fName,".")+1));

                    $this->fNewName     =   addcslashes(htmlentities(time()."-".$this->uid."-".$this->fName), $this->dataTESC);
                    $this->fLocation    =   "attachments/".$this->fNewName;
                    
                    if($this->uploadFile($this->fNewName, $this->fLocation)){
                        $this->allFname .=  $this->fLocation.",";
                    }
                    else{   $this->goTO =   $this->goTOpage."?oid=".$this->oid."&&error=1&&msg=".urlencode("Failed to upload your attachments");   }
                    
                }
                
                $this->allFname =   substr($this->allFname,0, strlen($this->allFname)-1);
            }
            
            if($this->attachmentsER==0){
                if($this->postType=="status"){          $this->dt1Sql =   "INSERT INTO ustatus (uid,pid,ucomment,cdate) VALUES('$this->uid','$this->oid','".$this->pdataAR[0]."','$this->tddate')";  }
                else if($this->postType=="comment"){    $this->dt1Sql =   "INSERT INTO ucomments (uid,pid,ucomment,cdate) VALUES('$this->uid','$this->oid','".$this->pdataAR[0]."','$this->tddate')";  }
                $this->dt1Query   =   $this->mysqli->query($this->dt1Sql);
                if($this->dt1Query){
                            $this->goTO =   $this->goTOpage."?oid=".$this->oid."&&done=1&&msg=".urlencode("Your ".$this->postType." have been posted");
                }else{      $this->goTO =   $this->goTOpage."?oid=".$this->oid."&&error=1&&msg=".urlencode("Failed to post your ".$this->postType);    }
            }   
        }
        
        function uploadFile($tmpName,$location){
            if(move_uploaded_file($tmpName,$location)){
                return "tayar";
            }else{
                return "bado";
            }
            
        }
        
        
        function saveProfilePic(){
            
            $this->fName        =   $_FILES["ppic"]["name"];
            $this->ftmpName     =   $_FILES["ppic"]["tmp_name"];
            
            $this->fExtension   =   strtolower(substr($this->fName, strrpos($this->fName,".")+1));
            
            $this->fNewName     =   addcslashes(htmlentities(time()."-".$this->uid."-".$this->fName), $this->dataTESC);
            $this->fLocation    =   "upics/".$this->fNewName;
            
            if(move_uploaded_file($this->ftmpName, $this->fLocation)){
                $this->dt3Sql   =   "UPDATE sys_users SET upic='$this->fNewName' WHERE id='$this->uid'";
                $this->dt3Query =   $this->mysqli->query($this->dt3Sql);
                if($this->dt3Query){
                    $_SESSION["tls_upic"]  =   $this->fNewName;
                    $this->goTO     =   "user.php?action=change-pic&&done=1&&msg=".urlencode("profile picture was saved");
                }
                else{   $this->goTO =   "user.php?action=change-pic&&error=1&&msg=".urlencode("Failed to save your profile picture");  }
            }
            else{       $this->goTO =   "user.php?action=change-pic&&error=1&&msg=".urlencode("Failed to upload your image");  }
        }
        
        function output(){
            header("Location: $this->goTO");
        }
        
    } 
    
    $saver  =   new saver($mysqli);
    $saver->output();
    
?>