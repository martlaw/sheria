<?php session_start(); ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title>Requests</title>
        <?php include'head.php'; ?>
    </head>
    <body>
        <?php include 'nav.php'; ?>
        <?php if((isset($_SESSION["tls_login"]))&&($_SESSION["tls_login"]==true)):?>
            <div class="cards">
                <?php 
                
                    include 'nav.php';
                    include 'less/dba.php';
                    include 'dbconnect.php';
                    include 'ifunc.php';
                    $ifunc          =   new ifunc($mysqli);
                    
                    
                    
                ?>
                
                
                <div id="b-leftCards">
                    
                    <div class="posts">
                        <div id="rheading">New forum posts</div>
                        <div id="p-post">
                            <div id="post-heading">
                                <div id="post-ppic" style="background:url(upics/<?php echo $_SESSION["tls_upic"]; ?>);"></div> 
                                <a href="profile.php?uid=<?php echo $_SESSION["tls_uid"]; ?>" id="md-lnk"><?php echo $_SESSION["tls_uname"]; ?></a>
                                <div id="oti"><?php echo date("M d, Y");?></div>
                            </div>
                            
                            <!-- user comment-->
                            <div class="uinarea">
                                <form action="saver.php?job=new-forum-post" method="post" enctype="multipart/form-data">
                                    <div id="ndatarow">
                                        <textarea id="fuin" name="upost" placeholder="share your comment"></textarea>
                                        <input type="hidden" class="attachments-status" name="attachments-status" value="hamna"/>
                                    </div>
                                    <div id="attachments">

                                    </div>
                                    <div class="rseter">
                                        <div id="attach">
                                            <div id="attachIco"><img src="icons/attachment.png"/></div>
                                            <input type="file" id="attachIn" name="attachments[]" multiple="multiple"/>
                                            <div id="attachTitle">Attachments</div>
                                        </div>
                                        <button id="submit">post</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div id="rheading">Forum posts</div>
                        <?php
                            # get profile posts
                            $postsCond  =   "ORDER BY pid DESC";
                            echo $ifunc->getPosts($postsCond);
                        ?>
                    </div>
                </div>

                <?php include 'right-cards.php'; ?>
            </div>
        <?php else:?>
        
        <?php endif;?>
    </body>
</html>