<header id="main-header">
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">

        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
          <div id="top-logo-icon"> <img src="archive/icons/icon.png"/> </div>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
          <ul class="nav navbar-nav navbar-right">
            <li class="active"><a href="#main-header">Home</a></li>
            <li class=""><a href="#feature">About</a></li>
            <li class=""><a href="#testimonial">Testimonial</a></li>
            <li class=""><a href="#blog">Articles</a></li>
            <li class=""><a href="#blog">Templates</a></li>
            
            <?php if(isset($_SESSION["tls_login"])&&$_SESSION["tls_login"]==true):?>
                <li class=""><a href="archive/door.php?job=logout">Logout</a></li>
            <?php else:?>
                <li class=""><a href="archive/index.php?action=login">Login</a></li>
                <li class=""><a href="archive/index.php?action=register">Register</a></li>
            <?php endif;?>
            <li class=""><a href="#contact">Contact Us</a></li>
          </ul>
        </div>
      </div>
    </nav>
  </header>