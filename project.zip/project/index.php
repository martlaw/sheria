<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>LegalBank Africa - TM</title>
  <meta name="description" content="Free Bootstrap Theme by BootstrapMade.com">
  <meta name="keywords" content="free website templates, free bootstrap themes, free template, free bootstrap, free website template">

  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:400,300|Raleway:300,400,900,700italic,700,300,600">
  <link rel="stylesheet" type="text/css" href="css/jquery.bxslider.css">
  <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/animate.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <!-- ==================================================
   BLESS MGONGOLWA | EDUMEK SYSTEMS
   
  ======================================================= -->
</head>

<body>
    <style>
        #top-logo-icon{width:80%;padding:5% 0% 0% 0%;margin:0% 0% 0% 0%;}
        #top-logo-icon img{width:100%;}
    </style>
    
  <div class="loader"></div>
  <div id="myDiv">
    <!--HEADER-->
    <div class="header">
      <div class="bg-color">
        <?php include 'nav.php'; ?>
        <div class="wrapper">
          <div class="container">
            <div class="row">
              <div class="banner-info text-center wow fadeIn delay-05s">
                <h1 class="bnr-title">We are ESHERIA</h1>
                <h2 class="bnr-sub-title">ONLINE LEGAL DOCUMENTS ARCHIVE</h2>
                <p class="bnr-para">we are introducing a new way for lawyers, advocates and law school students to browse through <br>thousands of legal documents </p>
                <div class="brn-btn">
                  <a href="archive/index.php?action=register" class="btn btn-download">Register now</a>
                  <a href="#feature" class="btn btn-more">Learn More</a>
                </div>
                <div class="overlay-detail">
                  <a href="#feature"><i class="fa fa-angle-down"></i></a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--/ HEADER-->
    <!---->
    <section id="feature" class="section-padding wow fadeIn delay-05s">
      <div class="container">
        <div class="row">
          <div class="col-md-3 col-sm-6 col-xs-12">
            <div class="wrap-item text-center">
              <div class="item-img">
                  <img src="img/lawyer.png">
              </div>
              <h3 class="pad-bt15">Lawyer Consultation</h3>
              <p>Chat with reputable lawyer(s) and get quick legal advice.</p>
            </div>
          </div>
          <div class="col-md-3 col-sm-6 col-xs-12">
            <div class="wrap-item text-center">
              <div class="item-img">
                  <img src="img/database.png">
              </div>
              <h3 class="pad-bt15">Judgement database</h3>
              <p>Throw away those large books. Quickly refer to past cases and build a defence of your own.</p>
            </div>
          </div>
          <div class="col-md-3 col-sm-6 col-xs-12">
            <div class="wrap-item text-center">
              <div class="item-img">
              <img src="img/constitution.png">
              </div>
              <h3 class="pad-bt15">Constitution</h3>
              <p>A customized constitution for easy reference of laws and articles.</p>
            </div>
          </div>
          <div class="col-md-3 col-sm-6 col-xs-12">
            <div class="wrap-item text-center">
              <div class="item-img">
                <img src="img/ser04.png">
              </div>
              <h3 class="pad-bt15">Secure</h3>
              <p>High end technology adopted for safety of user information</p>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!---->
    <!---->
    
    <!---->
    <!---->
    <!---->
    <!---->
    
    <!---->
    <!---->
    <!--<section id="testimonial" class="wow fadeInUp delay-05s">
      <div class="bg-testicolor">
        <div class="container section-padding">
          <div class="row">
            <div class="testimonial-item">
              <ul class="bxslider">
                <li>
                  <blockquote>
                    <img src="img/thumb.png" class="img-responsive">
                    <p>Come a day there won't be room for naughty men like us to slip about at all. This job goes south, there well may not be another. </p>
                  </blockquote>
                  <small>Shaun Paul, Client</small>
                </li>
                <li>
                  <blockquote>
                    <img src="img/thumb.png" class="img-responsive">
                    <p>So here is us, on the raggedy edge. Don't push me, and I won't push you. </p>
                  </blockquote>
                  <small>Marry Smith, Client</small>
                </li>
                <li>
                  <blockquote>
                    <img src="img/thumb.png" class="img-responsive">
                    <p>Come a day there won't be room for naughty men like us to slip about at all. This job goes south, there well may not be another.</p>
                  </blockquote>
                  <small>Vivek Singh, Client</small>
                </li>
                <li>
                  <blockquote>
                    <img src="img/thumb.png" class="img-responsive">
                    <p>So here is us, on the raggedy edge. Don't push me, and I won't push you.</p>
                  </blockquote>
                  <small>John Doe, Client</small>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>-->
    <!---->
    <section id="blog" class="section-padding wow fadeInUp delay-05s">
      <div class="container">
        <div class="row">
          <div class="col-md-12 text-center">
            <h2 class="service-title pad-bt15">Latest Articles</h2>
            <p class="sub-title pad-bt15">Take your time to read articles prepared exclusive from LegalBank Africa.</p>
            <hr class="bottom-line">
          </div>
            
          <?php
                include 'archive/less/dbconnect.php';
                include 'archive/less/dba.php';
                include 'archive/less/ifunc.php';
                include 'archive/less/less.php';
                
                $ifunc      =   new ifunc($mysqli);
                $less       =   new less();
                $lessTB     =   "web_data";
                $lessCOND   =   "WHERE dtype='article' ORDER BY id DESC LIMIT 3";   
                $dba        =   new dba($mysqli[1], $lessTB, $lessCOND); 
                $lessDATA   =   $dba->getData();
                $lessDATA   =   $dba->dataTRA;
                
                
                
                for($a=0;$a<count($lessDATA);$a++){
                    $postFiles  =   $ifunc->getFilesArrays($lessDATA[$a]["udata3"]);
                    $postImage  =   $postFiles[0];
                    $postSnipet =   $less->removeUncompleteHtml(substr($lessDATA[$a]["udata1"],0,300));
                    echo '<div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="blog-sec">
                              <div class="blog-img">
                                <a href="">
                                  <img src="archive/less/'.$postImage.'" class="img-responsive">
                                </a>
                              </div>
                              <div class="blog-info">
                                <h2>'.$lessDATA[$a]["udata2"].'</h2>
                                <div class="blog-comment">
                                  <p>Posted by: <span>LegalBank Africa</span></p>
                                  <p>
                                    <span><a href="#"><i class="fa fa-comments"></i></a> 15</span>
                                    <span><a href="#"><i class="fa fa-eye"></i></a> 11</span></p>
                                </div>
                                <p  style="margin:1% 0% 1% 0%;">'.$postSnipet.'</p>
                                <a href="#" class="read-more">Read more →</a>
                              </div>
                            </div>
                          </div>';
                }
                
          ?>  
            
        </div>
      </div>
    </section>
    <!---->
    <section id="contact" class="section-padding wow fadeInUp delay-05s">
      <div class="container">
        <div class="row">
          <div class="col-md-12 text-center white">
            <h2 class="service-title pad-bt15">Keep in touch with us</h2>
            <p class="sub-title pad-bt15">You have anything to tell us? just use information below to get in touch with us</p>
            <hr class="bottom-line white-bg">
          </div>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <div class="loction-info white">
              <p><i class="fa fa-map-marker fa-fw pull-left fa-2x"></i>Dar es salaam<br>Tanzania, </p>
              <p><i class="fa fa-envelope-o fa-fw pull-left fa-2x"></i>info@legalbankafrica.com</p>
              <p><i class="fa fa-phone fa-fw pull-left fa-2x"></i>+255 715 063 885</p>
            </div>
          </div>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <div class="contact-form">
              <div id="sendmessage">Your message has been sent. Thank you!</div>
              <div id="errormessage"></div>
              <form action="" method="post" role="form" class="contactForm">
                <div class="col-md-6 padding-right-zero">
                  <div class="form-group">
                    <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                    <div class="validation"></div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" data-rule="email" data-msg="Please enter a valid email" />
                    <div class="validation"></div>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject" />
                    <div class="validation"></div>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <textarea class="form-control" name="message" rows="5" data-rule="required" data-msg="Please write something for us" placeholder="Message"></textarea>
                    <div class="validation"></div>
                  </div>
                  <button type="submit" class="btn btn-primary btn-submit">SEND NOW</button>
                </div>
              </form>

            </div>
          </div>
        </div>
      </div>
    </section>
    <!---->
    <!---->
    <footer id="footer">
      <div class="container">
        <div class="row text-center">
          <p>&copy; ESHERIA. All Rights Reserved.</p>
        </div>
      </div>
    </footer>
    <!---->
  </div>
  <script src="js/jquery.min.js"></script>
  <script src="js/jquery.easing.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/wow.js"></script>
  <script src="js/jquery.bxslider.min.js"></script>
  <script src="js/custom.js"></script>
  <script src="contactform/contactform.js"></script>

</body>
</html>
